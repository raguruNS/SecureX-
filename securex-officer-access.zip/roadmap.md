# SECUREX account management
- [x] Strengthen the officer dashboard and verify administrator-only officer creation and removal, including existing-session revocation; open dashboards recheck access every 10 seconds. Verification officer access removed after testing.
- [x] Secure shared account storage, admin-only provisioning and password updates, audit history.
- [x] Polished officer directory, profile creation, password-change forms and sign-in.
- [x] Provision first administrator securely with user-supplied credentials.
- [x] Verify administrator/officer permissions, limits and end-to-end account workflow.
- [x] Continue account administration with audited disabling/reactivation, capacity checks and last-super-admin protection.

# Approved public and staff milestone
- [x] Separate public home/registration, staff login, administrator workspace and officer dashboard; enforce staff-only access on pages and every private action.
- [x] Create premium public home and details-collection pages, using the supplied references for the flow rather than exact colours/layout; retain SECUREX branding.
- [x] Build maintained location choices and citizen registration → authorized officer review → citizen status workflow.
- [x] Verify citizen submission, jurisdiction-scoped review, citizen status, and private-page access end to end.

# Before real-world registration
- [ ] Administrator must supply confirmed district, town and station coverage; synthetic verification coverage is disabled.

# Later approved milestones
- Citizen correction/resubmission and administrator-selected maintained station assignments.
- Properties and house monitoring, visits, QRT coordination, incidents and reports remain future stages, not active services.

# Current requested update
- [x] Add administrator Watch Cases with Karnataka district/town filters, citizen details and audited dismissal, and fix dashboard navigation alignment. Verified registration → administrator filtered details and watch timings → dismissal → citizen-visible reason; 55 tests passed, mobile has no page overflow, build OK.
- [x] Add a corner citizen Dismiss button with required reason/description and confirmation; active officer lists exclude dismissed profiles, and dismissal history remains accessible. Verified 36 tests and current build.
- [x] Move Police Watch into registration address details, save optional paired IST timings, remove the home link, and show saved timings in citizen tracking and officer details. Verified registration → citizen tracking → reload, database timestamps, and 46 tests; removed synthetic registration.
- [ ] Verify the officer's watch-details dialog while signed in; blocked by unavailable officer verification credentials.
- [ ] Verify approval → corner dismissal → citizen-visible reason end to end; UI and audited decision path are implemented, but signed-in verification is blocked by unavailable officer verification credentials.
- [x] Enable confirmed Anekal coverage and check ANK-18 district/station alignment, Register eligibility and saved-registration routing; saved watch verification used the maintained Anekal location.
- [x] Add Karnataka state, all 31 district choices and 219 district-dependent town/taluk-headquarters entries to citizen household registration; tested selection resets and confirmed service-coverage checks on desktop and 502px screens. This is not an exhaustive village directory.
- [x] Restyle the watch-request page with citizen ID and start/end date/time fields from the reference, without claiming a live police service.
- [x] Add public-page back navigation and premium Support, Citizen sign in and Staff login buttons.
- [x] Check interrupted citizen changes and verify updated pages; nullable RPC typing corrected, existing tests pass. Correction/resubmission and reassignment are not yet end-to-end verified.
- [x] Explain secure staff credential access without revealing saved secrets.
