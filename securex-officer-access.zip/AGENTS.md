<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Staff identities use app-owned PostgreSQL accounts, separate roles and encrypted HTTP-only TanStack sessions, rather than Cloud Auth identities, so self-service Auth password APIs cannot bypass administrator-only password changes.
- All staff reads and writes use server functions that validate the encrypted session against enabled status and session version; privileged database access is necessary because these identities do not have Cloud Auth JWTs.
- Provision staff and update passwords through transactional database functions with advisory locks and audit inserts, to keep capacity checks and history atomic.
- Bootstrap the initial administrator only through scripts/bootstrap-admin.ts using deployment secrets, never through a public endpoint or page-load seed.
- Account status changes use a locked database transaction that revalidates administrator access, capacity and last-super-admin protection, increments the session version, and inserts audit history so reactivation cannot restore old sessions.
- Staff workspaces use a shared periodic identity watcher to hide cached private content after revocation or failed access checks; independent server checks remain authoritative on every action.
- Public services, administrator controls and officer workspaces use separate named routes; staff page guards call the app-owned encrypted-session identity function and every private server function independently revalidates permissions.
- Citizen sessions use a separate encrypted HTTP-only cookie from staff sessions; citizen registration never grants staff roles or staff access.
- Service coverage is administrator-maintained; officer review reads and transactional decisions require both district and station matches to avoid invented coverage or cross-jurisdiction access.
- Registration dismissal uses the audited REJECTED decision, never record deletion; the transaction permits dismissal after approval, and the citizen's session-scoped timeline merges reviews and registration events to preserve police decision history.
- Administrator Watch Cases use session-validated filtered reads and a separate locked administrator dismissal transaction; dismissal inserts review history without deleting citizen records or changing officer jurisdiction permissions.
- Citizen address selectors use a separate geographic catalog; resolve district/town selections to an existing enabled service-location ID before submission, so geographic availability never invents police coverage.
- Public subpages share history-aware back navigation with a home fallback; Police Watch periods are optional paired timestamps saved atomically with household registration, interpreted in Asia/Kolkata and read only through citizen-session or jurisdiction-validated staff functions. Saved periods never imply dispatch or watch confirmation.
- Staff and citizen session cookies are Secure, SameSite=None and partitioned so sign-in works inside the cross-site editor preview frame.
