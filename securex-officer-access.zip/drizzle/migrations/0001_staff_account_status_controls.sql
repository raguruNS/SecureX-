CREATE OR REPLACE FUNCTION public.set_staff_enabled(p_actor uuid, p_target uuid, p_enabled boolean, p_reason text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE target_enabled boolean; target_roles text[]; active_count integer;
BEGIN
  PERFORM pg_advisory_xact_lock(701001);
  IF p_enabled IS NULL OR p_reason IS NULL OR length(trim(p_reason)) < 5 OR length(trim(p_reason)) > 500 THEN RAISE EXCEPTION 'A valid status and reason are required'; END IF;
  IF NOT EXISTS(SELECT 1 FROM public.staff_accounts a JOIN public.staff_roles r ON r.user_id=a.id WHERE a.id=p_actor AND a.enabled AND r.role IN ('ADMINISTRATOR','SUPER_ADMIN')) THEN RAISE EXCEPTION 'Administrator access required'; END IF;
  SELECT enabled INTO target_enabled FROM public.staff_accounts WHERE id=p_target FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Account not found'; END IF;
  IF target_enabled=p_enabled THEN RAISE EXCEPTION 'Account already has this status'; END IF;
  SELECT array_agg(role) INTO target_roles FROM public.staff_roles WHERE user_id=p_target;
  IF NOT p_enabled AND 'SUPER_ADMIN'=ANY(target_roles) AND (SELECT count(*) FROM public.staff_accounts a JOIN public.staff_roles r ON r.user_id=a.id WHERE a.enabled AND r.role='SUPER_ADMIN') <= 1 THEN RAISE EXCEPTION 'The last enabled super administrator must remain active'; END IF;
  IF p_enabled AND 'POLICE_OFFICER'=ANY(target_roles) THEN
    SELECT count(DISTINCT a.id) INTO active_count FROM public.staff_accounts a JOIN public.staff_roles r ON r.user_id=a.id WHERE a.enabled AND r.role='POLICE_OFFICER';
    IF active_count >= 50 THEN RAISE EXCEPTION 'The 50 active officer limit has been reached'; END IF;
  END IF;
  IF p_enabled AND (target_roles && ARRAY['ADMINISTRATOR','SUPER_ADMIN']::text[]) THEN
    SELECT count(DISTINCT a.id) INTO active_count FROM public.staff_accounts a JOIN public.staff_roles r ON r.user_id=a.id WHERE a.enabled AND r.role IN ('ADMINISTRATOR','SUPER_ADMIN');
    IF active_count >= 5 THEN RAISE EXCEPTION 'The 5 active administrator limit has been reached'; END IF;
  END IF;
  UPDATE public.staff_accounts SET enabled=p_enabled,session_version=session_version+1 WHERE id=p_target;
  INSERT INTO public.account_audit(actor_id,target_id,action,reason) VALUES(p_actor,p_target,CASE WHEN p_enabled THEN 'ACCOUNT_REACTIVATED' ELSE 'ACCOUNT_DISABLED' END,trim(p_reason));
END;
$$;
REVOKE ALL ON FUNCTION public.set_staff_enabled(uuid,uuid,boolean,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.set_staff_enabled(uuid,uuid,boolean,text) TO service_role;