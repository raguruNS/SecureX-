CREATE TABLE public.service_locations (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), district text NOT NULL, town text NOT NULL, station text NOT NULL, enabled boolean NOT NULL DEFAULT true, UNIQUE(district,town));
GRANT SELECT,INSERT,UPDATE ON public.service_locations TO service_role;
ALTER TABLE public.service_locations ENABLE ROW LEVEL SECURITY;
CREATE TABLE public.citizen_registrations (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), citizen_id text NOT NULL UNIQUE, full_name text NOT NULL, mobile text NOT NULL UNIQUE, location_id uuid NOT NULL REFERENCES public.service_locations(id), door_number text NOT NULL, address text NOT NULL, latitude double precision, longitude double precision, location_source text NOT NULL DEFAULT 'not_provided' CHECK(location_source IN ('not_provided','manual','device')), location_accuracy double precision, location_captured_at timestamptz, password_hash text NOT NULL, consent_at timestamptz NOT NULL DEFAULT now(), status text NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','APPROVED','REJECTED','CORRECTION_REQUESTED')), reviewer_remarks text, reviewed_by uuid REFERENCES public.staff_accounts(id), created_at timestamptz NOT NULL DEFAULT now(), reviewed_at timestamptz, CHECK(latitude IS NULL OR latitude BETWEEN -90 AND 90), CHECK(longitude IS NULL OR longitude BETWEEN -180 AND 180), CHECK((latitude IS NULL) = (longitude IS NULL)));
GRANT SELECT,INSERT,UPDATE ON public.citizen_registrations TO service_role;
ALTER TABLE public.citizen_registrations ENABLE ROW LEVEL SECURITY;
CREATE TABLE public.registration_reviews (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), registration_id uuid NOT NULL REFERENCES public.citizen_registrations(id), actor_id uuid NOT NULL REFERENCES public.staff_accounts(id), status text NOT NULL, reason text NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
GRANT SELECT,INSERT ON public.registration_reviews TO service_role;
ALTER TABLE public.registration_reviews ENABLE ROW LEVEL SECURITY;
CREATE INDEX citizen_location_status_idx ON public.citizen_registrations(location_id,status);
CREATE OR REPLACE FUNCTION public.review_citizen_registration(p_actor uuid,p_version integer,p_target uuid,p_status text,p_reason text) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE a public.staff_accounts%ROWTYPE; r public.citizen_registrations%ROWTYPE; l public.service_locations%ROWTYPE;
BEGIN
SELECT * INTO a FROM public.staff_accounts WHERE id=p_actor FOR UPDATE;
IF NOT FOUND OR NOT a.enabled OR a.session_version<>p_version OR NOT EXISTS(SELECT 1 FROM public.staff_roles WHERE user_id=p_actor AND role='POLICE_OFFICER') THEN RAISE EXCEPTION 'Officer access required'; END IF;
IF p_status NOT IN ('APPROVED','REJECTED','CORRECTION_REQUESTED') OR length(trim(p_reason))<5 OR length(p_reason)>500 THEN RAISE EXCEPTION 'Invalid review'; END IF;
SELECT * INTO r FROM public.citizen_registrations WHERE id=p_target FOR UPDATE;
IF NOT FOUND OR r.status NOT IN ('PENDING','CORRECTION_REQUESTED') THEN RAISE EXCEPTION 'Registration is not awaiting review'; END IF;
SELECT * INTO l FROM public.service_locations WHERE id=r.location_id;
IF NOT l.enabled OR lower(trim(l.district))<>lower(trim(a.district)) OR lower(trim(l.station))<>lower(trim(a.station)) THEN RAISE EXCEPTION 'Outside officer jurisdiction'; END IF;
UPDATE public.citizen_registrations SET status=p_status,reviewer_remarks=trim(p_reason),reviewed_by=p_actor,reviewed_at=now() WHERE id=p_target;
INSERT INTO public.registration_reviews(registration_id,actor_id,status,reason) VALUES(p_target,p_actor,p_status,trim(p_reason));
END $$;
REVOKE ALL ON FUNCTION public.review_citizen_registration(uuid,integer,uuid,text,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.review_citizen_registration(uuid,integer,uuid,text,text) TO service_role;
CREATE OR REPLACE FUNCTION public.maintain_service_location(p_actor uuid,p_version integer,p_district text,p_town text,p_station text,p_reason text) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE result uuid;
BEGIN
PERFORM 1 FROM public.staff_accounts a WHERE a.id=p_actor AND a.enabled AND a.session_version=p_version AND EXISTS(SELECT 1 FROM public.staff_roles WHERE user_id=a.id AND role IN ('ADMINISTRATOR','SUPER_ADMIN')) FOR UPDATE;
IF NOT FOUND THEN RAISE EXCEPTION 'Administrator access required'; END IF;
IF length(trim(p_district))<2 OR length(trim(p_town))<2 OR length(trim(p_station))<2 OR length(trim(p_reason))<5 THEN RAISE EXCEPTION 'Complete location details and reason required'; END IF;
INSERT INTO public.service_locations(district,town,station) VALUES(trim(p_district),trim(p_town),trim(p_station)) ON CONFLICT(district,town) DO UPDATE SET station=excluded.station RETURNING id INTO result;
INSERT INTO public.account_audit(actor_id,target_id,action,reason) VALUES(p_actor,p_actor,'SERVICE_LOCATION_UPDATED',trim(p_reason));
RETURN result;
END $$;
REVOKE ALL ON FUNCTION public.maintain_service_location(uuid,integer,text,text,text,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.maintain_service_location(uuid,integer,text,text,text,text) TO service_role;