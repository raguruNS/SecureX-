CREATE OR REPLACE FUNCTION public.admin_dismiss_citizen_registration(p_actor uuid, p_version integer, p_target uuid, p_reason text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE a public.staff_accounts%ROWTYPE; r public.citizen_registrations%ROWTYPE;
BEGIN
 SELECT * INTO a FROM public.staff_accounts WHERE id=p_actor FOR UPDATE;
 IF NOT FOUND OR NOT a.enabled OR a.session_version<>p_version OR NOT EXISTS(SELECT 1 FROM public.staff_roles WHERE user_id=p_actor AND role IN ('ADMINISTRATOR','SUPER_ADMIN')) THEN RAISE EXCEPTION 'Administrator access required'; END IF;
 IF p_reason IS NULL OR length(trim(p_reason))<5 OR length(trim(p_reason))>500 THEN RAISE EXCEPTION 'A recorded dismissal reason is required'; END IF;
 SELECT * INTO r FROM public.citizen_registrations WHERE id=p_target FOR UPDATE;
 IF NOT FOUND OR r.status NOT IN ('PENDING','CORRECTION_REQUESTED','APPROVED') THEN RAISE EXCEPTION 'Registration cannot be dismissed'; END IF;
 UPDATE public.citizen_registrations SET status='REJECTED',reviewer_remarks=trim(p_reason),reviewed_by=p_actor,reviewed_at=now(),updated_at=now(),version=version+1 WHERE id=p_target;
 INSERT INTO public.registration_reviews(registration_id,actor_id,status,reason) VALUES(p_target,p_actor,'REJECTED',trim(p_reason));
END;
$function$;
REVOKE ALL ON FUNCTION public.admin_dismiss_citizen_registration(uuid,integer,uuid,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.admin_dismiss_citizen_registration(uuid,integer,uuid,text) TO service_role;