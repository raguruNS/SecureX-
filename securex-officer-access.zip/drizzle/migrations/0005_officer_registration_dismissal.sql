CREATE OR REPLACE FUNCTION public.review_citizen_registration(p_actor uuid, p_version integer, p_target uuid, p_status text, p_reason text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $function$
DECLARE a public.staff_accounts%ROWTYPE; r public.citizen_registrations%ROWTYPE; l public.service_locations%ROWTYPE;
BEGIN
SELECT * INTO a FROM public.staff_accounts WHERE id=p_actor FOR UPDATE;
IF NOT FOUND OR NOT a.enabled OR a.session_version<>p_version OR NOT EXISTS(SELECT 1 FROM public.staff_roles WHERE user_id=p_actor AND role='POLICE_OFFICER') THEN RAISE EXCEPTION 'Officer access required'; END IF;
IF p_status IS NULL OR p_reason IS NULL OR p_status NOT IN ('APPROVED','REJECTED','CORRECTION_REQUESTED') OR length(trim(p_reason))<5 OR length(p_reason)>500 THEN RAISE EXCEPTION 'Invalid review'; END IF;
SELECT * INTO r FROM public.citizen_registrations WHERE id=p_target FOR UPDATE;
IF NOT FOUND OR NOT (r.status IN ('PENDING','CORRECTION_REQUESTED') OR (r.status='APPROVED' AND p_status='REJECTED')) THEN RAISE EXCEPTION 'Registration cannot receive this decision'; END IF;
SELECT * INTO l FROM public.service_locations WHERE id=r.location_id;
IF NOT FOUND OR NOT l.enabled OR lower(trim(l.district))<>lower(trim(a.district)) OR lower(trim(l.station))<>lower(trim(a.station)) THEN RAISE EXCEPTION 'Outside officer jurisdiction'; END IF;
UPDATE public.citizen_registrations SET status=p_status,reviewer_remarks=trim(p_reason),reviewed_by=p_actor,reviewed_at=now(),updated_at=now(),version=version+1 WHERE id=p_target;
INSERT INTO public.registration_reviews(registration_id,actor_id,status,reason) VALUES(p_target,p_actor,p_status,trim(p_reason));
END $function$;
REVOKE ALL ON FUNCTION public.review_citizen_registration(uuid,integer,uuid,text,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.review_citizen_registration(uuid,integer,uuid,text,text) TO service_role;