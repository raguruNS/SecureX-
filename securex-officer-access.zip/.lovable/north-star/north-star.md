<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Citizens' homes are watched over by local police while they are away.

## Metric

Household watch requests approved by an officer each week
