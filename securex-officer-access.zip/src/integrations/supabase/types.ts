export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      account_audit: {
        Row: {
          action: string
          actor_id: string | null
          created_at: string
          id: string
          reason: string
          target_id: string | null
        }
        Insert: {
          action: string
          actor_id?: string | null
          created_at?: string
          id?: string
          reason: string
          target_id?: string | null
        }
        Update: {
          action?: string
          actor_id?: string | null
          created_at?: string
          id?: string
          reason?: string
          target_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "account_audit_actor_id_fkey"
            columns: ["actor_id"]
            isOneToOne: false
            referencedRelation: "staff_accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_audit_target_id_fkey"
            columns: ["target_id"]
            isOneToOne: false
            referencedRelation: "staff_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      citizen_registrations: {
        Row: {
          address: string
          citizen_id: string
          consent_at: string
          created_at: string
          door_number: string
          full_name: string
          id: string
          latitude: number | null
          location_accuracy: number | null
          location_captured_at: string | null
          location_id: string
          location_source: string
          longitude: number | null
          mobile: string
          nearby_police_station: string
          password_hash: string
          reviewed_at: string | null
          reviewed_by: string | null
          reviewer_remarks: string | null
          status: string
          updated_at: string
          version: number
          watch_end_at: string | null
          watch_start_at: string | null
        }
        Insert: {
          address: string
          citizen_id: string
          consent_at?: string
          created_at?: string
          door_number: string
          full_name: string
          id?: string
          latitude?: number | null
          location_accuracy?: number | null
          location_captured_at?: string | null
          location_id: string
          location_source?: string
          longitude?: number | null
          mobile: string
          nearby_police_station?: string
          password_hash: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          reviewer_remarks?: string | null
          status?: string
          updated_at?: string
          version?: number
          watch_end_at?: string | null
          watch_start_at?: string | null
        }
        Update: {
          address?: string
          citizen_id?: string
          consent_at?: string
          created_at?: string
          door_number?: string
          full_name?: string
          id?: string
          latitude?: number | null
          location_accuracy?: number | null
          location_captured_at?: string | null
          location_id?: string
          location_source?: string
          longitude?: number | null
          mobile?: string
          nearby_police_station?: string
          password_hash?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          reviewer_remarks?: string | null
          status?: string
          updated_at?: string
          version?: number
          watch_end_at?: string | null
          watch_start_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "citizen_registrations_location_id_fkey"
            columns: ["location_id"]
            isOneToOne: false
            referencedRelation: "service_locations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "citizen_registrations_reviewed_by_fkey"
            columns: ["reviewed_by"]
            isOneToOne: false
            referencedRelation: "staff_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      login_attempts: {
        Row: {
          attempt_key: string
          attempts: number
          window_start: string
        }
        Insert: {
          attempt_key: string
          attempts?: number
          window_start?: string
        }
        Update: {
          attempt_key?: string
          attempts?: number
          window_start?: string
        }
        Relationships: []
      }
      registration_events: {
        Row: {
          actor_id: string | null
          created_at: string
          detail: string
          event: string
          id: string
          registration_id: string
        }
        Insert: {
          actor_id?: string | null
          created_at?: string
          detail: string
          event: string
          id?: string
          registration_id: string
        }
        Update: {
          actor_id?: string | null
          created_at?: string
          detail?: string
          event?: string
          id?: string
          registration_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "registration_events_actor_id_fkey"
            columns: ["actor_id"]
            isOneToOne: false
            referencedRelation: "staff_accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "registration_events_registration_id_fkey"
            columns: ["registration_id"]
            isOneToOne: false
            referencedRelation: "citizen_registrations"
            referencedColumns: ["id"]
          },
        ]
      }
      registration_reviews: {
        Row: {
          actor_id: string
          created_at: string
          id: string
          reason: string
          registration_id: string
          status: string
        }
        Insert: {
          actor_id: string
          created_at?: string
          id?: string
          reason: string
          registration_id: string
          status: string
        }
        Update: {
          actor_id?: string
          created_at?: string
          id?: string
          reason?: string
          registration_id?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "registration_reviews_actor_id_fkey"
            columns: ["actor_id"]
            isOneToOne: false
            referencedRelation: "staff_accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "registration_reviews_registration_id_fkey"
            columns: ["registration_id"]
            isOneToOne: false
            referencedRelation: "citizen_registrations"
            referencedColumns: ["id"]
          },
        ]
      }
      service_locations: {
        Row: {
          district: string
          enabled: boolean
          id: string
          station: string
          town: string
        }
        Insert: {
          district: string
          enabled?: boolean
          id?: string
          station: string
          town: string
        }
        Update: {
          district?: string
          enabled?: boolean
          id?: string
          station?: string
          town?: string
        }
        Relationships: []
      }
      staff_accounts: {
        Row: {
          created_at: string
          district: string
          email: string | null
          enabled: boolean
          full_name: string
          id: string
          login_id: string
          password_changed_at: string
          password_hash: string
          rank: string
          session_version: number
          station: string
        }
        Insert: {
          created_at?: string
          district?: string
          email?: string | null
          enabled?: boolean
          full_name: string
          id?: string
          login_id: string
          password_changed_at?: string
          password_hash: string
          rank?: string
          session_version?: number
          station?: string
        }
        Update: {
          created_at?: string
          district?: string
          email?: string | null
          enabled?: boolean
          full_name?: string
          id?: string
          login_id?: string
          password_changed_at?: string
          password_hash?: string
          rank?: string
          session_version?: number
          station?: string
        }
        Relationships: []
      }
      staff_roles: {
        Row: {
          role: string
          user_id: string
        }
        Insert: {
          role: string
          user_id: string
        }
        Update: {
          role?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "staff_roles_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "staff_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_dismiss_citizen_registration: {
        Args: {
          p_actor: string
          p_reason: string
          p_target: string
          p_version: number
        }
        Returns: undefined
      }
      change_staff_password: {
        Args: {
          p_actor: string
          p_hash: string
          p_reason: string
          p_target: string
        }
        Returns: undefined
      }
      maintain_service_location: {
        Args: {
          p_actor: string
          p_district: string
          p_reason: string
          p_station: string
          p_town: string
          p_version: number
        }
        Returns: string
      }
      provision_staff: {
        Args: {
          p_actor: string
          p_district: string
          p_email: string
          p_hash: string
          p_login: string
          p_name: string
          p_rank: string
          p_reason: string
          p_role: string
          p_station: string
        }
        Returns: string
      }
      reassign_registration_station: {
        Args: {
          p_actor: string
          p_location: string
          p_reason: string
          p_target: string
          p_version: number
        }
        Returns: undefined
      }
      resubmit_citizen_registration: {
        Args: {
          p_accuracy: number
          p_address: string
          p_captured: string
          p_citizen: string
          p_door: string
          p_lat: number
          p_lng: number
          p_location: string
          p_source: string
        }
        Returns: undefined
      }
      review_citizen_registration: {
        Args: {
          p_actor: string
          p_reason: string
          p_status: string
          p_target: string
          p_version: number
        }
        Returns: undefined
      }
      set_staff_enabled: {
        Args: {
          p_actor: string
          p_enabled: boolean
          p_reason: string
          p_target: string
        }
        Returns: undefined
      }
      staff_login_throttle: { Args: { p_key: string }; Returns: boolean }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
