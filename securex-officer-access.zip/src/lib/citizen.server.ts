import { useSession } from '@tanstack/react-start/server'
export async function citizenSession() {
  const secret = process.env['SECUREX_SESSION_SECRET']
  if (!secret) throw new Error('Secure sessions are unavailable')
  return useSession<{ citizenId?: string }>({ name: 'securex-citizen', password: secret, maxAge: 60 * 60 * 8, cookie: { httpOnly: true, secure: true, sameSite: 'none', partitioned: true, path: '/' } })
}
