// Reference catalog of district towns and taluk headquarters, not an exhaustive village directory.
// Sources: https://ceg.karnataka.gov.in/aadhaar/public/page/Contact+Us/Contact+details+of+Tahsildars/en
// https://bengalurusouth.nic.in/en/revenue-administration/
// https://vijayanagara.nic.in/en/collectorate/ and district revenue portals.
// Cross-check: https://en.wikipedia.org/wiki/List_of_taluks_of_Karnataka
// Geography does not indicate enabled police service coverage.
export const KARNATAKA_STATE = 'Karnataka'
export const KARNATAKA_TOWNS: Record<string, string[]> = {
  "Bagalkote": [
    "Badami",
    "Bagalkote",
    "Bilagi",
    "Guledgudda",
    "Hunagund",
    "Ilkal",
    "Jamakhandi",
    "Mudhol",
    "Rabkavi-Banahatti"
  ],
  "Ballari": [
    "Ballari",
    "Kurugodu",
    "Kampli",
    "Sanduru",
    "Siruguppa"
  ],
  "Belagavi": [
    "Belagavi",
    "Athani",
    "Bailhongal",
    "Chikkodi",
    "Gokak",
    "Hukkeri",
    "Khanapur",
    "Mudalgi",
    "Nippani",
    "Raibag",
    "Ramdurg",
    "Saundatti"
  ],
  "Bengaluru Rural": [
    "Devanahalli",
    "Doddaballapura",
    "Hoskote",
    "Nelamangala"
  ],
  "Bengaluru South": [
    "Channapatna",
    "Kanakapura",
    "Magadi",
    "Ramanagara",
    "Harohalli"
  ],
  "Bengaluru Urban": [
    "Bengaluru",
    "Anekal",
    "Bengaluru North",
    "Bengaluru South",
    "K.R. Puram",
    "Yelahanka"
  ],
  "Bidar": [
    "Aurad",
    "Bhalki",
    "Bidar",
    "Chitguppa",
    "Humnabad",
    "Basavakalyan"
  ],
  "Chamarajanagar": [
    "Chamarajanagar",
    "Gundlupet",
    "Kollegal",
    "Yelandur",
    "Hanur"
  ],
  "Chikkaballapura": [
    "Bagepalli",
    "Chikkaballapura",
    "Chintamani",
    "Gauribidanur",
    "Gudibanda",
    "Manchenahalli",
    "Sidlaghatta"
  ],
  "Chikkamagaluru": [
    "Chikkamagaluru",
    "Kadur",
    "Koppa",
    "Mudigere",
    "N.R. Pura",
    "Sringeri",
    "Tarikere",
    "Ajjampura",
    "Kalasa"
  ],
  "Chitradurga": [
    "Challakere",
    "Chitradurga",
    "Hiriyur",
    "Holalkere",
    "Hosadurga",
    "Molakalmuru"
  ],
  "Dakshina Kannada": [
    "Bantwal",
    "Belthangady",
    "Kadaba",
    "Mangaluru",
    "Moodabidri",
    "Mulki",
    "Puttur",
    "Sullia",
    "Ullal"
  ],
  "Davanagere": [
    "Channagiri",
    "Davanagere",
    "Harihar",
    "Honnali",
    "Nyamati",
    "Jagalur"
  ],
  "Dharwad": [
    "Dharwad",
    "Hubballi",
    "Kalghatgi",
    "Kundgol",
    "Navalgund",
    "Alnavar",
    "Annigeri"
  ],
  "Gadag": [
    "Gadag",
    "Betageri",
    "Mundargi",
    "Nargund",
    "Ron",
    "Shirahatti",
    "Lakshmeshwar"
  ],
  "Hassan": [
    "Alur",
    "Arkalgud",
    "Arsikere",
    "Belur",
    "Channarayapatna",
    "Hassan",
    "Holenarasipura",
    "Sakleshpur"
  ],
  "Haveri": [
    "Byadgi",
    "Hangal",
    "Haveri",
    "Hirekerur",
    "Ranebennur",
    "Savanur",
    "Shiggaon"
  ],
  "Kalaburagi": [
    "Afzalpur",
    "Aland",
    "Chincholi",
    "Chittapur",
    "Kalaburagi",
    "Jewargi",
    "Sedam",
    "Shahabad"
  ],
  "Kodagu": [
    "Madikeri",
    "Somwarpet",
    "Virajpet",
    "Ponnampet",
    "Kushalnagar"
  ],
  "Kolar": [
    "Bangarapet",
    "Kolar",
    "Malur",
    "Mulbagal",
    "Srinivaspur"
  ],
  "Koppal": [
    "Gangavathi",
    "Koppal",
    "Kushtagi",
    "Yelburga",
    "Kanakagiri",
    "Karatagi"
  ],
  "Mandya": [
    "Krishnarajpet",
    "Maddur",
    "Malavalli",
    "Mandya",
    "Nagamangala",
    "Pandavapura",
    "Srirangapatna"
  ],
  "Mysuru": [
    "H.D. Kote",
    "Hunsur",
    "Krishnarajanagara",
    "Mysuru",
    "Nanjangud",
    "Periyapatna",
    "T. Narasipura",
    "Saragur"
  ],
  "Raichur": [
    "Devadurga",
    "Lingsugur",
    "Manvi",
    "Raichur",
    "Sindhanur",
    "Maski"
  ],
  "Shivamogga": [
    "Bhadravati",
    "Hosanagara",
    "Sagar",
    "Shikaripura",
    "Shivamogga",
    "Sorab",
    "Tirthahalli"
  ],
  "Tumakuru": [
    "Chiknayakanhalli",
    "Gubbi",
    "Koratagere",
    "Kunigal",
    "Madhugiri",
    "Pavagada",
    "Sira",
    "Tiptur",
    "Tumakuru",
    "Turuvekere"
  ],
  "Udupi": [
    "Brahmavar",
    "Byndoor",
    "Karkala",
    "Kaup",
    "Kundapura",
    "Hebri",
    "Udupi"
  ],
  "Uttara Kannada": [
    "Ankola",
    "Bhatkal",
    "Dandeli",
    "Haliyal",
    "Honnavar",
    "Joida",
    "Karwar",
    "Kumta",
    "Mundgod",
    "Siddapur",
    "Sirsi",
    "Yellapur"
  ],
  "Vijayanagara": [
    "Hosapete",
    "Kotturu",
    "Kudligi",
    "Harapanahalli",
    "Hagaribommanahalli",
    "Hoovina Hadagali"
  ],
  "Vijayapura": [
    "Basavana Bagewadi",
    "Vijayapura",
    "Chadchan",
    "Indi",
    "Muddebihal",
    "Sindagi",
    "Talikoti",
    "Tikota"
  ],
  "Yadgir": [
    "Gurmitkal",
    "Shahapur",
    "Shorapur",
    "Yadgir",
    "Hunasagi",
    "Vadagera"
  ]
}
