import { createServerFn } from '@tanstack/react-start'
import { setResponseHeader, getRequestIP } from '@tanstack/react-start/server'
import { z } from 'zod'
import { hash, compare } from 'bcryptjs'
import type { SupabaseClient } from '@supabase/supabase-js'
import type { Database } from '@/integrations/supabase/types'
import { currentStaff } from './staff.server'
import { citizenSession } from './citizen.server'
import { canReview, canMakeReviewDecision, registrationSchema, reviewSchema, locationSchema, resubmitSchema, reassignSchema } from './citizen-policy'
import { adminCaseFilterSchema, adminDismissSchema, matchesCaseLocation, canAdminDismiss } from './admin-cases-policy'

// PostgreSQL permits NULL arguments; generated RPC types omit their nullability.
type ResubmitDatabase = Omit<Database, 'public'> & { public: Omit<Database['public'], 'Functions'> & { Functions: Omit<Database['public']['Functions'], 'resubmit_citizen_registration'> & { resubmit_citizen_registration: { Args: Omit<Database['public']['Functions']['resubmit_citizen_registration']['Args'], 'p_lat' | 'p_lng' | 'p_accuracy' | 'p_captured'> & { p_lat: number | null; p_lng: number | null; p_accuracy: number | null; p_captured: string | null }; Returns: undefined } } } }

export const getServiceLocations = createServerFn({ method: 'GET' }).handler(async () => {
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const { data, error } = await supabaseAdmin.from('service_locations').select('id,district,town,station').eq('enabled', true).order('district').order('town')
  if (error) throw new Error('Service locations are temporarily unavailable')
  return data ?? []
})
export const saveServiceLocation = createServerFn({ method: 'POST' }).inputValidator(v => locationSchema.parse(v)).handler(async ({ data }) => {
  const me = await currentStaff(true)
  if (!me) throw new Error('Administrator access required')
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const { error } = await supabaseAdmin.rpc('maintain_service_location', { p_actor: me.id, p_version: me.session_version, p_district: data.district, p_town: data.town, p_station: data.station, p_reason: data.reason })
  if (error) throw new Error('Location could not be saved')
  return { ok: true }
})
async function throttle(keyInput: string) {
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const digest = await crypto.subtle.digest('SHA-256',new TextEncoder().encode(keyInput))
  const key = Array.from(new Uint8Array(digest)).map(n => n.toString(16).padStart(2,'0')).join('')
  const { data, error } = await supabaseAdmin.rpc('staff_login_throttle',{ p_key: key })
  if (error || !data) throw new Error('Too many attempts. Try again in 15 minutes.')
}
export const registerCitizen = createServerFn({ method: 'POST' }).inputValidator(v => registrationSchema.parse(v)).handler(async ({ data }) => {
  await throttle(`registration:${getRequestIP() ?? 'unknown'}`)
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const { data: location } = await supabaseAdmin.from('service_locations').select('id').eq('id',data.location_id).eq('enabled',true).maybeSingle()
  if (!location) throw new Error('Select a currently available service location')
  const citizenId = `SX-${crypto.randomUUID().replaceAll('-','').slice(0,16).toUpperCase()}`
  const { password, consent: _consent, ...details } = data
  const { data: row, error } = await supabaseAdmin.from('citizen_registrations').insert({ ...details, citizen_id: citizenId, password_hash: await hash(password,12) }).select('id,citizen_id,status').single()
  if (error || !row) throw new Error('Registration could not be saved. If already registered, use Citizen sign in.')
  const session = await citizenSession(); await session.update({ citizenId: row.id })
  setResponseHeader('Cache-Control','no-store')
  return { citizen_id: row.citizen_id, status: row.status }
})
export const signInCitizen = createServerFn({ method: 'POST' }).inputValidator(v => z.object({ citizen_id: z.string().trim().min(3).max(40).transform(s => s.toUpperCase()), password: z.string().min(1).max(72) }).parse(v)).handler(async ({ data }) => {
  await throttle(`citizen:${getRequestIP() ?? 'unknown'}:${data.citizen_id}`)
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const { data: row, error } = await supabaseAdmin.from('citizen_registrations').select('id,password_hash').eq('citizen_id',data.citizen_id).maybeSingle()
  if (error || !row || !(await compare(data.password,row.password_hash))) return { ok: false, error: 'Incorrect citizen ID or password.' }
  const session = await citizenSession(); await session.update({ citizenId: row.id })
  return { ok: true, error: '' }
})
export const getCitizenStatus = createServerFn({ method: 'GET' }).handler(async () => {
  setResponseHeader('Cache-Control','no-store')
  const session = await citizenSession()
  if (!session.data.citizenId) return null
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const { data, error } = await supabaseAdmin.from('citizen_registrations').select('citizen_id,full_name,status,reviewer_remarks,created_at,reviewed_at,watch_start_at,watch_end_at,service_locations(district,town,station)').eq('id',session.data.citizenId).maybeSingle()
  if (error) throw new Error('Registration status is unavailable')
  return data
})
export const signOutCitizen = createServerFn({ method: 'POST' }).handler(async () => { const session = await citizenSession(); await session.clear(); return { ok: true } })
export const resubmitCitizenRegistration = createServerFn({ method: 'POST' }).inputValidator(v => resubmitSchema.parse(v)).handler(async ({ data }) => {
  setResponseHeader('Cache-Control','no-store')
  const session = await citizenSession()
  if (!session.data.citizenId) throw new Error('Sign in to update your registration')
  await throttle(`resubmit:${getRequestIP() ?? 'unknown'}`)
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const resubmitClient = supabaseAdmin as unknown as SupabaseClient<ResubmitDatabase>
  const { error } = await resubmitClient.rpc('resubmit_citizen_registration', { p_citizen: session.data.citizenId, p_location: data.location_id, p_door: data.door_number, p_address: data.address, p_lat: data.latitude, p_lng: data.longitude, p_source: data.location_source, p_accuracy: data.location_accuracy, p_captured: data.location_captured_at })
  if (error) throw new Error('Resubmission was not accepted. Only rejected or correction-requested registrations can be updated.')
  return { ok: true }
})
export const getRegistrationEvents = createServerFn({ method: 'GET' }).handler(async () => {
  setResponseHeader('Cache-Control','no-store')
  const session = await citizenSession()
  if (!session.data.citizenId) return []
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const { data, error } = await supabaseAdmin.from('registration_events').select('id,event,detail,created_at').eq('registration_id',session.data.citizenId).order('created_at',{ ascending: false }).limit(50)
  const { data: reviews, error: reviewError } = await supabaseAdmin.from('registration_reviews').select('id,status,reason,created_at').eq('registration_id',session.data.citizenId).order('created_at',{ ascending: false }).limit(50)
  if (error || reviewError) throw new Error('Registration history is unavailable')
  return [...(data ?? []), ...(reviews ?? []).map(r => ({ id: r.id, event: r.status, detail: r.reason, created_at: r.created_at }))].sort((a,b) => Date.parse(b.created_at)-Date.parse(a.created_at)).slice(0,100)
})
export const getAdminRegistrations = createServerFn({ method: 'GET' }).handler(async () => {
  setResponseHeader('Cache-Control','no-store')
  const me = await currentStaff(true)
  if (!me) throw new Error('Administrator access required')
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const { data: registrations, error } = await supabaseAdmin.from('citizen_registrations').select('id,citizen_id,full_name,status,location_id,created_at').order('created_at',{ ascending: false }).limit(200)
  const { data: locations, error: locationError } = await supabaseAdmin.from('service_locations').select('id,district,town,station,enabled').order('district').order('town')
  if (error || locationError) throw new Error('Unable to load registrations')
  return { registrations: registrations ?? [], locations: locations ?? [] }
})
export const getAdminWatchCases = createServerFn({ method: 'GET' }).inputValidator(v => adminCaseFilterSchema.parse(v)).handler(async ({ data }) => {
  setResponseHeader('Cache-Control','no-store')
  if (!(await currentStaff(true))) throw new Error('Administrator access required')
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const { data: locations, error: locationError } = await supabaseAdmin.from('service_locations').select('id,district,town,station').order('district').order('town')
  if (locationError) throw new Error('Unable to load case locations')
  const ids = (locations ?? []).filter(l => matchesCaseLocation(l,data)).map(l => l.id)
  if (!ids.length) return { registrations: [], locations: locations ?? [] }
  let query = supabaseAdmin.from('citizen_registrations').select('id,citizen_id,full_name,mobile,door_number,address,nearby_police_station,latitude,longitude,location_source,location_accuracy,location_captured_at,status,location_id,created_at,reviewer_remarks,reviewed_at,watch_start_at,watch_end_at').in('location_id',ids).order('created_at',{ ascending: false }).limit(200)
  if (data.status === 'ACTIVE') query = query.in('status',['PENDING','CORRECTION_REQUESTED','APPROVED'])
  if (data.status === 'REJECTED') query = query.eq('status','REJECTED')
  const { data: registrations, error } = await query
  if (error) throw new Error('Unable to load citizen cases')
  return { registrations: registrations ?? [], locations: locations ?? [] }
})
export const dismissAdminCitizen = createServerFn({ method: 'POST' }).inputValidator(v => adminDismissSchema.parse(v)).handler(async ({ data }) => {
  setResponseHeader('Cache-Control','no-store')
  const me = await currentStaff(true)
  if (!me) throw new Error('Administrator access required')
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const { data: row, error: readError } = await supabaseAdmin.from('citizen_registrations').select('status').eq('id',data.target_id).maybeSingle()
  if (readError || !row || !canAdminDismiss(me.roles,row.status)) throw new Error('This registration cannot be dismissed. Refresh the cases.')
  const { error } = await supabaseAdmin.rpc('admin_dismiss_citizen_registration',{ p_actor: me.id, p_version: me.session_version, p_target: data.target_id, p_reason: data.reason })
  if (error) throw new Error('Dismissal was not accepted. Refresh the cases and try again.')
  return { ok: true }
})
export const reassignRegistrationStation = createServerFn({ method: 'POST' }).inputValidator(v => reassignSchema.parse(v)).handler(async ({ data }) => {
  const me = await currentStaff(true)
  if (!me) throw new Error('Administrator access required')
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const { error } = await supabaseAdmin.rpc('reassign_registration_station', { p_actor: me.id, p_version: me.session_version, p_target: data.target_id, p_location: data.location_id, p_reason: data.reason })
  if (error) throw new Error('Reassignment was not accepted. Check the location and try again.')
  return { ok: true }
})
export const getOfficerWorkspace = createServerFn({ method: 'GET' }).handler(async () => {
  setResponseHeader('Cache-Control','no-store')
  const me = await currentStaff()
  if (!me?.roles.includes('POLICE_OFFICER')) throw new Error('Officer access required')
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const { data: locations, error: locationError } = await supabaseAdmin.from('service_locations').select('id,district,station,town').eq('enabled',true)
  if (locationError) throw new Error('Unable to load jurisdiction')
  const permitted = (locations ?? []).filter(l => canReview(me.roles,me,l))
  const ids = permitted.map(l => l.id)
  if (!ids.length) return { me, registrations: [], history: [], towns: [] as string[] }
  const { data: registrations, error } = await supabaseAdmin.from('citizen_registrations').select('id,citizen_id,full_name,mobile,door_number,address,nearby_police_station,latitude,longitude,status,location_id,created_at,reviewer_remarks,watch_start_at,watch_end_at').in('location_id',ids).order('created_at',{ ascending: false })
  const { data: history, error: historyError } = await supabaseAdmin.from('registration_reviews').select('id,registration_id,status,reason,created_at').eq('actor_id',me.id).order('created_at',{ ascending: false }).limit(100)
  if (error || historyError) throw new Error('Unable to load registrations')
  return { me, registrations: registrations ?? [], history: history ?? [], towns: permitted.map(l => l.town) }
})
export const reviewRegistration = createServerFn({ method: 'POST' }).inputValidator(v => reviewSchema.parse(v)).handler(async ({ data }) => {
  const me = await currentStaff()
  if (!me?.roles.includes('POLICE_OFFICER')) throw new Error('Officer access required')
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const { data: registration, error: readError } = await supabaseAdmin.from('citizen_registrations').select('status').eq('id',data.target_id).maybeSingle()
  if (readError || !registration || !canMakeReviewDecision(registration.status,data.status)) throw new Error('This registration cannot receive that decision. Refresh the queue.')
  const { error } = await supabaseAdmin.rpc('review_citizen_registration',{ p_actor: me.id, p_version: me.session_version, p_target: data.target_id, p_status: data.status, p_reason: data.reason })
  if (error) throw new Error('Review not permitted. Check your jurisdiction and refresh the queue.')
  return { ok: true }
})
