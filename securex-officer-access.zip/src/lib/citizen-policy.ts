import { z } from 'zod'
import { passwordSchema, isAdministrator } from './staff-policy'
import { watchPeriodSchema } from './watch-policy'
export function staffDestination(roles: string[]) { return isAdministrator(roles) ? '/admin' : roles.includes('POLICE_OFFICER') ? '/officer' : '/staff-login' }
export function canReview(roles: string[], officer: { district: string; station: string }, location: { district: string; station: string }) { return roles.includes('POLICE_OFFICER') && officer.district.trim().toLowerCase() === location.district.trim().toLowerCase() && officer.station.trim().toLowerCase() === location.station.trim().toLowerCase() }
const registrationBase = z.object({ full_name: z.string().trim().min(2).max(100), mobile: z.string().regex(/^[6-9]\d{9}$/, 'Enter a valid 10-digit mobile number'), location_id: z.string().uuid('Select your district and town'), door_number: z.string().trim().min(1).max(80), address: z.string().trim().min(10).max(500), latitude: z.number().min(-90).max(90).nullable(), longitude: z.number().min(-180).max(180).nullable(), location_source: z.enum(['manual','device','not_provided']), location_accuracy: z.number().nonnegative().nullable(), location_captured_at: z.string().datetime().nullable() })
const coordinateRules = <T extends z.ZodTypeAny>(s: T) => s
export const registrationSchema = registrationBase.extend({ nearby_police_station: z.string().trim().min(2,'Enter your nearby police station').max(120), password: passwordSchema, consent: z.literal(true) }).refine(v => (v.latitude === null) === (v.longitude === null), 'Provide both coordinates or leave both blank').refine(v => v.location_source !== 'device' || (v.latitude !== null && v.location_accuracy !== null && v.location_captured_at !== null), 'Capture location again').and(watchPeriodSchema)
export const reviewSchema = z.object({ target_id: z.string().uuid(), status: z.enum(['APPROVED','REJECTED','CORRECTION_REQUESTED']), reason: z.string().trim().min(5,'Add a reason of at least 5 characters').max(500) })
export function canMakeReviewDecision(currentStatus: string, decision: string) {
  if (!['APPROVED','REJECTED','CORRECTION_REQUESTED'].includes(decision)) return false
  return ['PENDING','CORRECTION_REQUESTED'].includes(currentStatus) || (currentStatus === 'APPROVED' && decision === 'REJECTED')
}
export function matchesRegistrationFilter(status: string, filter: string) {
  if (filter === 'ACTIVE') return ['PENDING','CORRECTION_REQUESTED','APPROVED'].includes(status)
  if (filter === 'ALL') return true
  if (filter === 'PENDING') return ['PENDING','CORRECTION_REQUESTED'].includes(status)
  return status === filter
}
export function registrationStatusLabel(status: string) {
  return status === 'REJECTED' ? 'Dismissed' : status === 'CORRECTION_REQUESTED' ? 'Correction requested' : status === 'APPROVED' ? 'Approved' : status === 'PENDING' ? 'Awaiting officer review' : status.replaceAll('_',' ')
}
export const locationSchema = z.object({ district: z.string().trim().min(2).max(80), town: z.string().trim().min(2).max(80), station: z.string().trim().min(2).max(120), reason: z.string().trim().min(5).max(500) })
export const resubmitSchema = registrationBase.refine(v => (v.latitude === null) === (v.longitude === null), 'Provide both coordinates or leave both blank').refine(v => v.location_source !== 'device' || (v.latitude !== null && v.location_accuracy !== null && v.location_captured_at !== null), 'Capture location again')
export const reassignSchema = z.object({ target_id: z.string().uuid(), location_id: z.string().uuid('Select a service location'), reason: z.string().trim().min(5,'Add a reason of at least 5 characters').max(500) })
