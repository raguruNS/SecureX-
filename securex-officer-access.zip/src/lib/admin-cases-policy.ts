import { z } from 'zod'
import { isAdministrator } from './staff-policy'
import { canMakeReviewDecision } from './citizen-policy'
import { locationKey, type RegistrationLocation } from './registration-location'
import { KARNATAKA_TOWNS } from './karnataka-towns'

export const adminCaseFilterSchema = z.object({ state: z.enum(['Karnataka', '']), district: z.string().trim().max(80), town: z.string().trim().max(80), status: z.enum(['ACTIVE','ALL','REJECTED']) }).refine(v => !v.district || Object.hasOwn(KARNATAKA_TOWNS,v.district), 'Select a Karnataka district').refine(v => !v.town || !!v.district, 'Select a district first')
export const adminDismissSchema = z.object({ target_id: z.string().uuid(), reason: z.string().trim().min(5,'Add a reason of at least 5 characters').max(500) })
export function canAdminDismiss(roles: string[], status: string) { return isAdministrator(roles) && canMakeReviewDecision(status,'REJECTED') }
export function matchesCaseLocation(location: RegistrationLocation, filter: { state: string; district: string; town: string }) {
  return filter.state === 'Karnataka' && (!filter.district || locationKey(location.district) === locationKey(filter.district)) && (!filter.town || locationKey(location.town) === locationKey(filter.town))
}