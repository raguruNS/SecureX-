export type RegistrationLocation = { id: string; district: string; town: string }

// Keep geographic labels separate from administrator-maintained service coverage.
const aliases: Record<string, string> = {
  bangalore: 'bengaluru urban', 'bengaluru': 'bengaluru urban',
  'bangalore urban': 'bengaluru urban', 'bangalore rural': 'bengaluru rural',
  ramanagara: 'bengaluru south', mysore: 'mysuru', mangalore: 'mangaluru',
  belgaum: 'belagavi', bellary: 'ballari', bijapur: 'vijayapura',
  gulbarga: 'kalaburagi', shimoga: 'shivamogga', tumkur: 'tumakuru',
  chikmagalur: 'chikkamagaluru', chikkaballapur: 'chikkaballapura',
  chamarajanagar: 'chamarajanagara', hospet: 'hosapete',
}

export function locationKey(value: string) {
  const key = value.trim().toLowerCase().replace(/\s+/g, ' ')
  return aliases[key] ?? key
}

export function findRegistrationLocation<T extends RegistrationLocation>(locations: T[], state: string, district: string, town: string) {
  if (state !== 'Karnataka' || !district || !town) return undefined
  return locations.find(location => locationKey(location.district) === locationKey(district) && locationKey(location.town) === locationKey(town))
}

export function districtTowns(district: string, catalog: Record<string, string[]>, locations: RegistrationLocation[]) {
  if (!district || !Object.hasOwn(catalog, district)) return []
  const towns = [...(catalog[district] ?? [])]
  for (const location of locations) {
    if (locationKey(location.district) === locationKey(district) && !towns.some(town => locationKey(town) === locationKey(location.town))) towns.push(location.town)
  }
  return towns.sort((a, b) => a.localeCompare(b))
}