import { z } from 'zod'

export const watchPeriodSchema = z.object({
  watch_start_at: z.string().datetime().nullable().default(null),
  watch_end_at: z.string().datetime().nullable().default(null),
}).superRefine((value, context) => {
  if ((value.watch_start_at === null) !== (value.watch_end_at === null)) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: 'Enter both watch start and end timings.' })
  } else if (value.watch_start_at && value.watch_end_at && Date.parse(value.watch_end_at) <= Date.parse(value.watch_start_at)) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: 'Watch end must be after watch start.' })
  }
})

export function watchTimestamp(date: string, time: string) {
  if (!date || !time) return null
  const timestamp = new Date(`${date}T${time}:00+05:30`)
  return Number.isNaN(timestamp.getTime()) ? null : timestamp.toISOString()
}

export function formatWatchTime(value: string) {
  return new Intl.DateTimeFormat('en-IN', { timeZone: 'Asia/Kolkata', day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit' }).format(new Date(value))
}