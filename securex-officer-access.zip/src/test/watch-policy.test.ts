import { describe, expect, it } from 'vitest'
import { watchPeriodSchema, watchTimestamp } from '@/lib/watch-policy'

describe('Household Police Watch timings', () => {
  it('allows a household to register without requesting a watch', () => {
    expect(watchPeriodSchema.parse({})).toEqual({ watch_start_at: null, watch_end_at: null })
  })
  it('requires both start and end when a watch is requested', () => {
    expect(watchPeriodSchema.safeParse({ watch_start_at: '2026-11-04T04:30:00.000Z', watch_end_at: null }).success).toBe(false)
  })
  it('rejects an end before the start', () => {
    expect(watchPeriodSchema.safeParse({ watch_start_at: '2026-11-05T04:30:00.000Z', watch_end_at: '2026-11-04T04:30:00.000Z' }).success).toBe(false)
  })
  it('rejects equal start and end timings', () => {
    expect(watchPeriodSchema.safeParse({ watch_start_at: '2026-11-04T04:30:00.000Z', watch_end_at: '2026-11-04T04:30:00.000Z' }).success).toBe(false)
  })
  it('accepts and preserves a complete watch period', () => {
    const period = { watch_start_at: '2026-11-04T04:30:00.000Z', watch_end_at: '2026-11-05T04:30:00.000Z' }
    expect(watchPeriodSchema.parse(period)).toEqual(period)
  })
  it('interprets registration dates and times in Karnataka time', () => {
    expect(watchTimestamp('2026-11-04', '10:00')).toBe('2026-11-04T04:30:00.000Z')
  })
})