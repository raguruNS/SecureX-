import { describe, expect, it } from 'vitest'
import { districtTowns, findRegistrationLocation } from '@/lib/registration-location'
import { KARNATAKA_STATE, KARNATAKA_TOWNS } from '@/lib/karnataka-towns'

describe('Karnataka household location selection', () => {
  it('provides Karnataka and all 31 districts with towns', () => {
    expect(KARNATAKA_STATE).toBe('Karnataka')
    expect(Object.keys(KARNATAKA_TOWNS)).toHaveLength(31)
    expect(KARNATAKA_TOWNS['Bengaluru South']).toContain('Ramanagara')
    expect(KARNATAKA_TOWNS['Vijayanagara']).toContain('Hosapete')
    expect(Object.values(KARNATAKA_TOWNS).every(towns => towns.length > 0)).toBe(true)
  })
  it('includes Karnataka towns in their own districts', () => {
    expect(districtTowns('Mysuru', KARNATAKA_TOWNS, [])).toContain('Nanjangud')
    expect(districtTowns('Mandya', KARNATAKA_TOWNS, [])).toContain('Maddur')
    expect(districtTowns('Mandya', KARNATAKA_TOWNS, [])).not.toContain('Nanjangud')
  })
  const locations = [
    { id: 'mysuru-location', district: 'Mysuru', town: 'Mysuru' },
    { id: 'mandya-location', district: 'Mandya', town: 'Maddur' },
  ]
  it('only supports Karnataka as the selected state', () => {
    expect(findRegistrationLocation(locations, 'Karnataka', 'Mysuru', 'Mysuru')?.id).toBe('mysuru-location')
    expect(findRegistrationLocation(locations, 'Kerala', 'Mysuru', 'Mysuru')).toBeUndefined()
  })
  it('shows towns from the selected district only', () => {
    expect(districtTowns('Mysuru', { Mysuru: ['Mysuru', 'Nanjangud'], Mandya: ['Maddur'] }, locations)).toEqual(['Mysuru', 'Nanjangud'])
  })
  it('does not treat a geographic town as confirmed police coverage', () => {
    expect(findRegistrationLocation(locations, 'Karnataka', 'Mysuru', 'Nanjangud')).toBeUndefined()
  })
  it('clears eligibility when a district changes but the old town remains', () => {
    expect(findRegistrationLocation(locations, 'Karnataka', 'Mandya', 'Mysuru')).toBeUndefined()
  })
  it('matches maintained coverage using legacy district names', () => {
    expect(findRegistrationLocation([{ id: 'legacy', district: 'Ramanagara', town: 'Channapatna' }], 'Karnataka', 'Bengaluru South', 'Channapatna')?.id).toBe('legacy')
  })
})