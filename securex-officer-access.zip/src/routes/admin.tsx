import { createFileRoute, redirect } from '@tanstack/react-router'
import { getStaffIdentity } from '@/lib/staff.functions'
import { isAdministrator } from '@/lib/staff-policy'
import { AdminWorkspace } from '@/components/securex/admin-workspace'
import { pageHead } from '@/components/securex/public-shell'
export const Route = createFileRoute('/admin')({ beforeLoad: async () => { const me = await getStaffIdentity(); if (!me) throw redirect({ to: '/staff-login' }); if (!isAdministrator(me.roles)) throw redirect({ to: '/officer' }) }, head: () => pageHead('Administrator workspace','Private officer account management and SECUREX access administration.'), component: AdminWorkspace, staleTime: 0 })
