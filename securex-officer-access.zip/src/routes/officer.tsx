import { createFileRoute, redirect, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { queryOptions, useSuspenseQuery, useQueryClient } from "@tanstack/react-query";
import { useState, type FormEvent } from "react";
import {
  ShieldCheck,
  ClipboardList,
  UserRound,
  Bell,
  Activity,
  LogOut,
  MapPin,
  Search,
  RefreshCw,
  CheckCircle2,
  LockKeyhole,
  Ban,
} from "lucide-react";
import { DismissCitizenForm } from "@/components/securex/dismiss-citizen-form";
import { WatchDetails } from "@/components/securex/watch-details";
import { Button } from "@/components/ui/button";
import { StaffAccessWatch } from "@/components/securex/staff-access-watch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { pageHead } from "@/components/securex/public-shell";
import { getStaffIdentity, signOutStaff } from "@/lib/staff.functions";
import { getOfficerWorkspace, reviewRegistration } from "@/lib/citizen.functions";
import { isAdministrator } from "@/lib/staff-policy";
import {
  reviewSchema,
  registrationStatusLabel,
  canMakeReviewDecision,
  matchesRegistrationFilter,
} from "@/lib/citizen-policy";
const officerQuery = queryOptions({
  queryKey: ["officer-workspace"],
  queryFn: () => getOfficerWorkspace(),
  staleTime: 0,
});
type Registration = Awaited<ReturnType<typeof getOfficerWorkspace>>["registrations"][number];
export const Route = createFileRoute("/officer")({
  beforeLoad: async () => {
    const me = await getStaffIdentity();
    if (!me) throw redirect({ to: "/officer-login" });
    if (isAdministrator(me.roles)) throw redirect({ to: "/admin" });
    if (!me.roles.includes("POLICE_OFFICER")) throw redirect({ to: "/officer-login" });
  },
  loader: ({ context }) => context.queryClient.fetchQuery(officerQuery),
  head: () =>
    pageHead(
      "Officer dashboard",
      "Private jurisdiction-based registration review and officer activity.",
    ),
  component: OfficerWorkspace,
  staleTime: 0,
});
function OfficerWorkspace() {
  return (
    <StaffAccessWatch>
      <Officer />
    </StaffAccessWatch>
  );
}
function Officer() {
  const { data, refetch, isFetching } = useSuspenseQuery(officerQuery);
  const qc = useQueryClient();
  const router = useRouter();
  const logout = useServerFn(signOutStaff);
  const review = useServerFn(reviewRegistration);
  const [tab, setTab] = useState<"queue" | "profile" | "notifications" | "activity">("queue");
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("ACTIVE");
  const [selected, setSelected] = useState<Registration | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [dismissMode, setDismissMode] = useState(false);
  function openProfile(registration: Registration, dismiss = false) {
    setSelected(registration);
    setDismissMode(dismiss);
    setError("");
  }
  const pending = data.registrations.filter(
    (r) => r.status === "PENDING" || r.status === "CORRECTION_REQUESTED",
  );
  const rows = data.registrations.filter(
    (r) =>
      matchesRegistrationFilter(r.status, filter) &&
      `${r.full_name} ${r.citizen_id} ${r.address}`.toLowerCase().includes(search.toLowerCase()),
  );
  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await logout();
    await router.invalidate();
    await router.navigate({ to: "/officer-login", replace: true });
  }
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!selected) return;
    setError("");
    const f = new FormData(e.currentTarget);
    const parsed = reviewSchema.safeParse({
      target_id: selected.id,
      status: f.get("status"),
      reason: f.get("reason"),
    });
    if (!parsed.success) {
      setError(parsed.error.issues[0]?.message ?? "Check the review.");
      return;
    }
    setBusy(true);
    try {
      await review({ data: parsed.data });
      await refetch();
      setSelected(null);
      setDismissMode(false);
      setNotice(
        parsed.data.status === "REJECTED"
          ? "Citizen profile dismissed and removed from the active list. The reason is saved in citizen tracking and history."
          : "Review saved. The citizen can now read the decision and remarks.",
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to save review.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="securex-shell officer-shell">
      <aside className="securex-sidebar">
        <div className="brand">
          <ShieldCheck className="brand-mark" />
          <div>
            <div className="brand-name">SECUREX</div>
            <div className="brand-sub">OFFICER WORKSPACE</div>
          </div>
        </div>
        <div className="nav-label">FIELD OPERATIONS</div>
        <nav className="side-nav" aria-label="Officer navigation">
          {(
            [
              { id: "queue", label: "Registration review", icon: ClipboardList },
              { id: "notifications", label: "Notifications", icon: Bell },
              { id: "profile", label: "My profile", icon: UserRound },
              { id: "activity", label: "My activity", icon: Activity },
            ] as const
          ).map((t) => (
            <Button
              key={t.id}
              variant="ghost"
              className={`nav-item ${tab === t.id ? "active" : ""}`}
              onClick={() => setTab(t.id)}
            >
              <t.icon />
              {t.label}
              {t.id === "notifications" && <span className="nav-count">{pending.length}</span>}
            </Button>
          ))}
        </nav>
        <div className="side-bottom">
          <div className="prototype-note">
            <strong>
              <ShieldCheck size={14} />
              Prototype environment
            </strong>
            Independent software.
            <br />
            Not emergency dispatch.
          </div>
          <div className="side-account">
            <span className="avatar">{data.me.full_name.slice(0, 2).toUpperCase()}</span>
            <div>
              <strong>{data.me.full_name}</strong>
              <small>{data.me.rank}</small>
            </div>
          </div>
        </div>
      </aside>
      <main className="securex-main">
        <header className="topbar">
          <div className="breadcrumbs">
            Officer workspace<strong>{data.me.station}</strong>
          </div>
          <div className="topbar-actions">
            <Button
              variant="ghost"
              size="icon"
              aria-label="Refresh officer workspace"
              title="Refresh workspace"
              disabled={isFetching}
              onClick={() => refetch()}
            >
              <RefreshCw className={isFetching ? "animate-spin" : ""} />
            </Button>
            <Button variant="ghost" onClick={signOut}>
              <LogOut />
              Sign out
            </Button>
          </div>
        </header>
        <div className="workspace">
          <div className="page-heading">
            <div>
              <div className="eyebrow">
                {data.me.district.toUpperCase() || "ASSIGNED JURISDICTION"}
              </div>
              <h1>
                {tab === "queue"
                  ? "Officer dashboard"
                  : tab === "profile"
                    ? "My profile"
                    : tab === "notifications"
                      ? "Notifications"
                      : "My activity"}
              </h1>
              <p>
                {data.me.station} ·{" "}
                {data.towns.length ? data.towns.join(", ") : "No service towns assigned yet"}
              </p>
            </div>
            <span className="badge success">
              <ShieldCheck size={13} />
              Officer access
            </span>
          </div>
          {notice && (
            <div className="permission-banner" role="status">
              <CheckCircle2 />
              {notice}
            </div>
          )}
          <div className="metrics officer-metrics">
            {[
              { label: "Awaiting review", value: pending.length },
              {
                label: "Approved registrations",
                value: data.registrations.filter((r) => r.status === "APPROVED").length,
              },
              { label: "My recorded reviews", value: data.history.length },
            ].map((m) => (
              <div className="metric" key={m.label}>
                <div className="metric-top">
                  {m.label}
                  <ClipboardList size={17} />
                </div>
                <div className="metric-value">{m.value}</div>
                <div className="metric-foot">Your assigned jurisdiction</div>
              </div>
            ))}
          </div>
          {tab === "queue" ? (
            <section className="directory">
              <div className="directory-heading">
                <div>
                  <h2>Citizen registration queue</h2>
                  <p>Only registrations within your district and station</p>
                </div>
                <span className="badge">{rows.length} registrations</span>
              </div>
              <div className="directory-toolbar">
                <div className="search-field">
                  <Search />
                  <input
                    className="field-input"
                    aria-label="Search registrations"
                    placeholder="Search name, citizen ID or address"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>
                <select
                  className="field-input"
                  aria-label="Filter registrations"
                  value={filter}
                  onChange={(e) => setFilter(e.target.value)}
                >
                  <option value="ACTIVE">Active profiles</option>
                  <option value="PENDING">Awaiting review</option>
                  <option value="APPROVED">Approved</option>
                  <option value="REJECTED">Dismissed</option>
                  <option value="ALL">All profiles & history</option>
                </select>
              </div>
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>CITIZEN</th>
                      <th>ADDRESS</th>
                      <th>RECEIVED</th>
                      <th>STATUS</th>
                      <th>ACTION</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((r) => (
                      <tr key={r.id}>
                        <td>
                          <div className="person-cell">
                            <span className="avatar">
                              <UserRound size={16} />
                            </span>
                            <div>
                              <strong>{r.full_name}</strong>
                              <small>{r.citizen_id}</small>
                            </div>
                          </div>
                        </td>
                        <td className="registration-address">
                          {r.door_number}, {r.address}
                          {r.nearby_police_station && (
                            <small className="registration-station">
                              Nearby station: {r.nearby_police_station}
                            </small>
                          )}
                        </td>
                        <td>{new Date(r.created_at).toLocaleDateString("en-IN")}</td>
                        <td>
                          <span
                            className={`badge ${r.status === "APPROVED" ? "success" : "neutral"}`}
                          >
                            {registrationStatusLabel(r.status)}
                          </span>
                        </td>
                        <td>
                          <Button variant="outline" size="sm" onClick={() => openProfile(r)}>
                            {["PENDING", "CORRECTION_REQUESTED"].includes(r.status)
                              ? "Review"
                              : "View"}
                          </Button>
                          {canMakeReviewDecision(r.status, "REJECTED") && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="ml-2 text-destructive"
                              aria-label={`Dismiss ${r.full_name}`}
                              title="Dismiss citizen profile"
                              onClick={() => openProfile(r, true)}
                            >
                              <Ban />
                            </Button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {!rows.length && (
                <div className="empty-directory">
                  <div className="empty-icon">
                    <ClipboardList />
                  </div>
                  <h3>
                    {!data.towns.length
                      ? "Service coverage has not been configured"
                      : "Your queue is clear"}
                  </h3>
                  <p>
                    {!data.towns.length
                      ? "Ask your administrator to add service towns matching your district and station."
                      : "No registrations match this view."}
                  </p>
                </div>
              )}
            </section>
          ) : tab === "profile" ? (
            <section className="officer-profile">
              <h2>{data.me.full_name}</h2>
              <dl className="profile-details">
                {[
                  ["Staff ID", data.me.login_id],
                  ["Rank", data.me.rank],
                  ["District", data.me.district],
                  ["Station", data.me.station],
                  ["Email", data.me.email || "Not provided"],
                ].map(([k, v]) => (
                  <div key={k}>
                    <dt>{k}</dt>
                    <dd>{v}</dd>
                  </div>
                ))}
              </dl>
              <div className="permission-banner">
                <LockKeyhole />
                <strong>Your password is managed only by your administrator.</strong>
              </div>
            </section>
          ) : tab === "notifications" ? (
            <section>
              <h2>Registrations awaiting attention</h2>
              {pending.length ? (
                pending.map((r) => (
                  <div className="activity" key={r.id}>
                    <Bell />
                    <div>
                      <strong>
                        {r.full_name} · {registrationStatusLabel(r.status)}
                      </strong>
                      <p>Received {new Date(r.created_at).toLocaleDateString("en-IN")}</p>
                      <Button variant="link" size="sm" onClick={() => openProfile(r)}>
                        Review registration
                      </Button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="empty-directory">
                  <Bell />
                  <h3>No pending notifications</h3>
                </div>
              )}
            </section>
          ) : (
            <section>
              <h2>Recorded review history</h2>
              {data.history.length ? (
                data.history.map((h) => (
                  <div className="activity" key={h.id}>
                    <CheckCircle2 />
                    <div>
                      <strong>{registrationStatusLabel(h.status)}</strong>
                      <p>{h.reason}</p>
                      <time>{new Date(h.created_at).toLocaleString("en-IN")}</time>
                    </div>
                  </div>
                ))
              ) : (
                <div className="empty-directory">
                  <Activity />
                  <h3>No reviews recorded yet</h3>
                </div>
              )}
            </section>
          )}
        </div>
      </main>
      <Dialog
        open={selected !== null}
        onOpenChange={(v) => {
          if (!v && !busy) {
            setSelected(null);
            setDismissMode(false);
            setError("");
          }
        }}
      >
        <DialogContent className="secure-dialog">
          <DialogHeader>
            <DialogTitle>Citizen registration</DialogTitle>
            <DialogDescription>{selected?.citizen_id}</DialogDescription>
          </DialogHeader>
          {selected && (
            <>
              <div className="flex justify-end">
                {canMakeReviewDecision(selected.status, "REJECTED") && !dismissMode && (
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => {
                      setDismissMode(true);
                      setError("");
                    }}
                  >
                    <Ban />
                    Dismiss profile
                  </Button>
                )}
              </div>
              <dl className="profile-details">
                {[
                  ["Full name", selected.full_name],
                  ["Mobile", selected.mobile],
                  ["Door number", selected.door_number],
                  ["Address", selected.address],
                  ["Nearby police station", selected.nearby_police_station || "Not provided"],
                  [
                    "Coordinates",
                    selected.latitude === null
                      ? "Not shared"
                      : `${selected.latitude}, ${selected.longitude}`,
                  ],
                  ["Status", registrationStatusLabel(selected.status)],
                ].map(([k, v]) => (
                  <div key={k}>
                    <dt>{k}</dt>
                    <dd>{v}</dd>
                  </div>
                ))}
              </dl>
              <WatchDetails start={selected.watch_start_at} end={selected.watch_end_at} />
              {dismissMode ? (
                <DismissCitizenForm
                  busy={busy}
                  error={error}
                  onSubmit={submit}
                  onCancel={() => {
                    setDismissMode(false);
                    setError("");
                  }}
                />
              ) : ["PENDING", "CORRECTION_REQUESTED"].includes(selected.status) ? (
                <form className="dialog-form" onSubmit={submit}>
                  <label className="form-field">
                    Decision
                    <select name="status" className="field-input" required>
                      {selected.status !== "APPROVED" && (
                        <option value="APPROVED">Approve registration</option>
                      )}
                      {selected.status !== "APPROVED" && (
                        <option value="CORRECTION_REQUESTED">Request correction</option>
                      )}
                    </select>
                  </label>
                  <label className="form-field">
                    Reason / citizen-visible remarks
                    <textarea
                      name="reason"
                      className="field-input address-input"
                      required
                      minLength={5}
                      maxLength={500}
                    />
                  </label>
                  {error && (
                    <p className="form-error" role="alert">
                      {error}
                    </p>
                  )}
                  <Button disabled={busy}>
                    <CheckCircle2 />
                    {busy ? "Saving review…" : "Save review"}
                  </Button>
                </form>
              ) : (
                <p className="form-note">{selected.reviewer_remarks}</p>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
