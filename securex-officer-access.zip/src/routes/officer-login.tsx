import { createFileRoute, useRouter, redirect } from '@tanstack/react-router'
import { useServerFn } from '@tanstack/react-start'
import { useState, type FormEvent } from 'react'
import { BadgeCheck, LogIn, ShieldCheck } from 'lucide-react'
import { PublicShell, PublicField, pageHead } from '@/components/securex/public-shell'
import { Button } from '@/components/ui/button'
import { getStaffIdentity, signInStaff } from '@/lib/staff.functions'
import { staffDestination } from '@/lib/citizen-policy'
export const Route = createFileRoute('/officer-login')({ beforeLoad: async () => { const me = await getStaffIdentity(); if (me) { const to = staffDestination(me.roles); if (to !== '/staff-login') throw redirect({ to }) } }, head: () => pageHead('Officer login','Private SECUREX access for administrator-issued officer accounts.'), component: OfficerLogin })
function OfficerLogin() {
  const router = useRouter(); const login = useServerFn(signInStaff); const identity = useServerFn(getStaffIdentity)
  const [error,setError] = useState(''); const [busy,setBusy] = useState(false)
  async function submit(e: FormEvent<HTMLFormElement>) { e.preventDefault(); setBusy(true); setError(''); const f = new FormData(e.currentTarget); try { const result = await login({ data: { login_id: String(f.get('login_id')),password: String(f.get('password')) } }); if (!result.ok) { setError(result.error); return } const me = await identity(); if (!me) throw new Error(); await router.invalidate(); await router.navigate({ to: staffDestination(me.roles),replace: true }) } catch { setError('Sign-in could not be completed. Please try again.') } finally { setBusy(false) } }
  return <PublicShell><main className="public-form-page login-page"><div className="form-intro"><span className="intro-icon"><BadgeCheck/></span><div className="eyebrow">OFFICERS ONLY</div><h1>Officer login</h1><p>Your duty dashboard. Securely connected.</p></div><form className="public-form login-form" onSubmit={submit}><PublicField label="Officer ID" name="login_id" autoComplete="username" maxLength={40}/><PublicField label="Password" name="password" type="password" autoComplete="current-password" maxLength={72}/>{error && <p className="form-error" role="alert">{error}</p>}<Button type="submit" size="lg" disabled={busy}><LogIn/>{busy ? 'Signing in…' : 'Sign in securely'}</Button><p className="form-note"><ShieldCheck size={14}/>Officer IDs and passwords are issued by your administrator. Contact them for access assistance.</p></form></main></PublicShell>
}
