import { useState, type FormEvent } from 'react'
import { useServerFn } from '@tanstack/react-start'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Ban, Eye, RefreshCw, Search } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import { HouseholdLocationFields } from './household-location-fields'
import { WatchDetails } from './watch-details'
import { DismissCitizenForm } from './dismiss-citizen-form'
import { KARNATAKA_TOWNS } from '@/lib/karnataka-towns'
import { registrationStatusLabel, canMakeReviewDecision } from '@/lib/citizen-policy'
import { adminDismissSchema } from '@/lib/admin-cases-policy'
import { getAdminWatchCases, dismissAdminCitizen } from '@/lib/citizen.functions'

type Case = Awaited<ReturnType<typeof getAdminWatchCases>>['registrations'][number]
export function AdminWatchCases() {
  const load = useServerFn(getAdminWatchCases)
  const dismiss = useServerFn(dismissAdminCitizen)
  const cache = useQueryClient()
  const [area,setArea] = useState({state:'Karnataka' as 'Karnataka' | '',district:'',town:''})
  const [status,setStatus] = useState<'ACTIVE'|'ALL'|'REJECTED'>('ACTIVE')
  const [search,setSearch] = useState('')
  const [selected,setSelected] = useState<Case | null>(null)
  const [dismissing,setDismissing] = useState(false)
  const [busy,setBusy] = useState(false)
  const [formError,setFormError] = useState('')
  const [notice,setNotice] = useState('')
  const {data,isPending,error,refetch} = useQuery({queryKey:['admin-watch-cases',area,status],queryFn:()=>load({data:{...area,status}}),retry:false})
  const locations=data?.locations ?? []
  const rows=(data?.registrations ?? []).filter(r=>`${r.full_name} ${r.citizen_id} ${r.mobile}`.toLowerCase().includes(search.toLowerCase()))
  const location=locations.find(l=>l.id===selected?.location_id)
  function open(row:Case,remove=false) { setSelected(row); setDismissing(remove); setFormError('') }
  async function submit(event:FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!selected) return
    const parsed=adminDismissSchema.safeParse({target_id:selected.id,reason:new FormData(event.currentTarget).get('reason')})
    if (!parsed.success) {setFormError(parsed.error.issues[0]?.message ?? 'Enter a dismissal reason');return}
    setBusy(true);setFormError('')
    try {
      await dismiss({data:parsed.data})
      setSelected(null);setDismissing(false);setNotice('Citizen profile dismissed. The reason remains in citizen tracking and dismissal history.')
      await cache.invalidateQueries({queryKey:['admin-watch-cases']})
      await cache.invalidateQueries({queryKey:['officer-workspace']})
    } catch(e) {setFormError(e instanceof Error?e.message:'Dismissal could not be completed')}
    finally {setBusy(false)}
  }
  return <section className="admin-cases">
    <div className="case-filters">
      <HouseholdLocationFields catalog={KARNATAKA_TOWNS} locations={locations} {...area} onChange={v=>setArea({...v,state:v.state==='Karnataka'?'Karnataka':''})}/>
      <label className="form-field">Case status<select className="field-input" value={status} onChange={e=>setStatus(e.target.value as typeof status)}><option value="ACTIVE">Active cases</option><option value="REJECTED">Dismissed profiles</option><option value="ALL">All cases</option></select></label>
      <div className="search-field"><Search size={14}/><input className="field-input" aria-label="Search citizen cases" placeholder="Name, citizen ID or mobile" value={search} onChange={e=>setSearch(e.target.value)}/></div>
    </div>
    {notice && <p className="mb-4 text-sm text-primary" role="status">{notice}</p>}
    <div className="directory-heading px-0 pb-5"><div><h2 className="font-semibold">Citizen cases <span className="badge neutral">{rows.length}</span></h2><p>Latest 200 matching registrations</p></div><Button variant="ghost" size="icon" aria-label="Refresh citizen cases" title="Refresh citizen cases" onClick={()=>refetch()}><RefreshCw/></Button></div>
    {error ? <p className="form-error" role="alert">Cases could not be loaded. Please refresh.</p> : isPending ? <p className="form-note py-8">Loading citizen cases…</p> : !rows.length ? <div className="empty-directory"><h3>No matching citizen cases</h3><p>{area.state ? 'No registrations match this location and status.' : 'Select Karnataka to view citizen cases.'}</p></div> : <div className="table-wrap"><table><thead><tr><th>CITIZEN</th><th>DISTRICT / TOWN</th><th>POLICE WATCH</th><th>STATUS</th><th>ACTIONS</th></tr></thead><tbody>{rows.map(row=>{const loc=locations.find(l=>l.id===row.location_id);return <tr key={row.id}><td><div className="person-cell"><div><strong>{row.full_name}</strong><small>{row.citizen_id}</small></div></div></td><td><div className="person-cell"><div><strong>{loc?.district ?? 'Unavailable'}</strong><small>{loc?.town}</small></div></div></td><td>{row.watch_start_at&&row.watch_end_at?'Timings saved':'Not requested'}</td><td><span className={`badge ${row.status==='APPROVED'?'success':'neutral'}`}>{registrationStatusLabel(row.status)}</span></td><td><div className="row-actions"><Button variant="ghost" size="icon" aria-label={`View citizen ${row.full_name}`} title="View citizen details" onClick={()=>open(row)}><Eye/></Button>{canMakeReviewDecision(row.status,'REJECTED')&&<Button variant="ghost" size="icon" aria-label={`Dismiss citizen ${row.full_name}`} title="Dismiss citizen profile" onClick={()=>open(row,true)}><Ban/></Button>}</div></td></tr>})}</tbody></table></div>}
    <Dialog open={selected!==null} onOpenChange={value=>{if(!value&&!busy){setSelected(null);setDismissing(false);setFormError('')}}}><DialogContent className="secure-dialog"><DialogHeader className="text-left"><DialogTitle>Citizen registration</DialogTitle><DialogDescription>{selected?.citizen_id}</DialogDescription></DialogHeader>{selected&&<>
      {canMakeReviewDecision(selected.status,'REJECTED')&&!dismissing&&<div className="flex justify-end"><Button variant="destructive" size="sm" onClick={()=>setDismissing(true)}><Ban/>Dismiss profile</Button></div>}
      <dl className="profile-details">{[['Full name',selected.full_name],['Mobile',selected.mobile],['State','Karnataka'],['District',location?.district ?? 'Unavailable'],['Town',location?.town ?? 'Unavailable'],['Assigned station',location?.station ?? 'Unavailable'],['Door number',selected.door_number],['Address',selected.address],['Nearby police station',selected.nearby_police_station||'Not provided'],['Coordinates',selected.latitude!==null&&selected.longitude!==null?`${selected.latitude}, ${selected.longitude}`:'Not shared'],['Location source',selected.location_source],['Registration status',registrationStatusLabel(selected.status)],['Registered',new Date(selected.created_at).toLocaleString('en-IN',{timeZone:'Asia/Kolkata'})]].map(([label,value])=><div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl>
      <WatchDetails start={selected.watch_start_at} end={selected.watch_end_at}/>
      {selected.reviewer_remarks&&<div className="border-t border-border pt-4"><h3 className="font-semibold">Latest decision / reason</h3><p className="mt-2 break-words text-sm text-muted-foreground">{selected.reviewer_remarks}</p></div>}
      {dismissing&&<DismissCitizenForm busy={busy} error={formError} onSubmit={submit} onCancel={()=>{setDismissing(false);setFormError('')}}/>}
    </>}</DialogContent></Dialog>
  </section>
}