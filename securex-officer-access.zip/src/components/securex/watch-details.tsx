import { CalendarDays } from 'lucide-react'
import { formatWatchTime } from '@/lib/watch-policy'

export function WatchDetails({ start, end }: { start: string | null; end: string | null }) {
  return <section className="mt-6 border-t border-border pt-6">
    <h2 className="flex items-center gap-2 text-lg font-semibold"><CalendarDays size={20}/>Police Watch</h2>
    {start && end ? <>
      <span className="badge neutral mt-3">Request saved · Awaiting watch confirmation</span>
      <dl className="profile-details">
        <div><dt>Watch starts · IST</dt><dd>{formatWatchTime(start)}</dd></div>
        <div><dt>Watch ends · IST</dt><dd>{formatWatchTime(end)}</dd></div>
      </dl>
      <p className="form-note">Registration approval does not confirm a watch assignment. No police deployment has been arranged through this prototype.</p>
    </> : <p className="form-note mt-3">No Police Watch requested.</p>}
  </section>
}