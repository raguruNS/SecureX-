import { Link, useRouter, useRouterState } from '@tanstack/react-router'
import { useQuery } from '@tanstack/react-query'
import { useServerFn } from '@tanstack/react-start'
import { getStaffIdentity } from '@/lib/staff.functions'
import { getCitizenStatus } from '@/lib/citizen.functions'
import { staffDestination } from '@/lib/citizen-policy'
import { ShieldCheck, ArrowUpRight, ArrowLeft, House, UserRound, LockKeyhole, BadgeCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import type { ReactNode } from 'react'
export function Brand() { return <Link to="/" className="public-brand" aria-label="SECUREX home"><span className="public-brand-mark"><House size={23}/><ShieldCheck size={13}/></span><span>SECUREX<small>HOME & COMMUNITY SAFETY</small></span></Link> }
export function PublicShell({ children }: { children: ReactNode }) {
  const identity = useServerFn(getStaffIdentity)
  const status = useServerFn(getCitizenStatus)
  const { data: staff } = useQuery({ queryKey: ['public-staff-session'], queryFn: () => identity(), retry: false })
  const { data: citizen } = useQuery({ queryKey: ['public-citizen-session'], queryFn: () => status(), retry: false })
  const router = useRouter()
  const pathname = useRouterState({ select: state => state.location.pathname })
  function goBack() { if (router.history.canGoBack()) router.history.back(); else void router.navigate({ to: '/' }) }
  return <div className="public-site"><header className="public-header"><Brand/><nav aria-label="Public navigation"><Button asChild variant="outline" className="public-nav-button citizen-nav"><Link to={citizen ? '/citizen-status' : '/citizen-login'}><UserRound/>{citizen ? 'My registration' : 'Citizen sign in'}</Link></Button><Button asChild variant="secondary" className="public-nav-button officer-nav"><Link to="/officer-login" activeProps={{ className: 'nav-current' }}><BadgeCheck/>Officer login</Link></Button><Button asChild className="public-nav-button staff-nav"><Link to={staff ? staffDestination(staff.roles) : '/staff-login'}><LockKeyhole/>{staff ? 'My workspace' : 'Administrator login'}<ArrowUpRight size={14}/></Link></Button></nav></header>{pathname !== '/' && <div className="public-back-bar"><Button variant="ghost" size="icon" aria-label="Go back" title="Go back" onClick={goBack}><ArrowLeft/></Button><span>Back</span></div>}{children}<footer className="public-footer"><Brand/><div><span>© 2026 SECUREX</span><Link to="/privacy">Privacy policy</Link><Link to="/support">Support</Link></div><p>Independent software prototype. Not an official police service or emergency dispatch.</p></footer></div>
}
export function pageHead(title: string, description: string) { return { meta: [{ title: `${title} | SECUREX` },{ name: 'description',content: description },{ property: 'og:title',content: `${title} | SECUREX` },{ property: 'og:description',content: description },{ property: 'og:type',content: 'website' },{ name: 'twitter:card',content: 'summary_large_image' }] } }
export function PublicField({ label, ...props }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) { return <label className="form-field">{label}<input className="field-input" required {...props}/></label> }
