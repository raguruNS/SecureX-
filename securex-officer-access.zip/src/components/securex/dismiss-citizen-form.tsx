import type { FormEvent } from 'react'
import { Ban } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function DismissCitizenForm({ busy, error, onSubmit, onCancel }: { busy: boolean; error: string; onSubmit: (event: FormEvent<HTMLFormElement>) => void; onCancel: () => void }) {
  return <form className="dialog-form border-t border-border pt-4" onSubmit={onSubmit}>
    <h3 className="font-semibold">Dismiss citizen profile</h3>
    <p className="form-note">This profile will leave the active list. The citizen will see your reason, and the decision stays in history.</p>
    <input type="hidden" name="status" value="REJECTED"/>
    <label className="form-field">Dismissal reason / description<textarea name="reason" className="field-input address-input" placeholder="Describe why this citizen registration is being dismissed" required minLength={5} maxLength={500} autoFocus disabled={busy}/></label>
    {error && <p className="form-error" role="alert">{error}</p>}
    <div className="flex flex-wrap justify-end gap-2">
      <Button type="button" variant="outline" disabled={busy} onClick={onCancel}>Cancel</Button>
      <Button type="submit" variant="destructive" disabled={busy}><Ban/>{busy ? 'Dismissing…' : 'Confirm dismissal'}</Button>
    </div>
  </form>
}