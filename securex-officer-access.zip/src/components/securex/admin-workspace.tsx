import { Link, useRouter } from '@tanstack/react-router'
import { useServerFn } from '@tanstack/react-start'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useState, type FormEvent } from 'react'
import { Users, ShieldCheck, KeyRound, Plus, Search, ChevronRight, ChevronLeft, LogOut, LogIn, Eye, CheckCircle2, LockKeyhole, Activity, ArrowUpRight, CircleHelp, Building2, UserCheck, RefreshCw, Shield, Download, UserX } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { AdminWatchCases } from './admin-watch-cases'
import { StaffAccessWatch } from '@/components/securex/staff-access-watch'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import { getStaffWorkspace, signInStaff, signOutStaff, createOfficer, changeStaffPassword, setStaffEnabled } from '@/lib/staff.functions'
import { isAdministrator, officerSchema, passwordSchema } from '@/lib/staff-policy'

type Workspace = Awaited<ReturnType<typeof getStaffWorkspace>>
type Account = Workspace['accounts'][number]
type Modal = 'login' | 'create' | 'password' | 'profile' | 'status' | 'help' | null
const initials = (name: string) => name.split(' ').filter(Boolean).slice(0, 2).map(part => part.charAt(0)).join('').toUpperCase()
const dateLabel = (date: string) => new Date(date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })

function Logo() { return <div className="brand"><svg className="brand-mark" viewBox="0 0 38 44" fill="none" aria-label="SECUREX shield and home"><path d="M19 2 35 8v13c0 10-9 16-16 21C12 37 3 31 3 21V8L19 2Z" fill="currentColor"/><path d="m10 21 9-8 9 8M13 20v10h12V20M18 30v-6h4v6" stroke="var(--nav-foreground)" strokeWidth="2.2" strokeLinejoin="round" strokeLinecap="round"/></svg><div><div className="brand-name">SECUREX</div><div className="brand-sub">PROTECT. CONNECT. SECURE.</div></div></div> }

export function AdminWorkspace() { return <StaffAccessWatch administrator><AdministratorContent/></StaffAccessWatch> }
function AdministratorContent() {
  const router = useRouter()
  const queryClient = useQueryClient()
  const loadWorkspace = useServerFn(getStaffWorkspace)
  const login = useServerFn(signInStaff)
  const logout = useServerFn(signOutStaff)
  const provision = useServerFn(createOfficer)
  const changePassword = useServerFn(changeStaffPassword)
  const changeStatus = useServerFn(setStaffEnabled)
  const { data, isPending, error, refetch } = useQuery({ queryKey: ['staff-workspace'], queryFn: () => loadWorkspace(), retry: false })
  const me = data?.me
  const admin = me ? isAdministrator(me.roles) : false
  const accounts = data?.accounts ?? []
  const officers = accounts.filter(account => account.roles.includes('POLICE_OFFICER'))
  const admins = accounts.filter(account => isAdministrator(account.roles))
  const audit = data?.audit ?? []
  const [tab, setTab] = useState<'officers' | 'security' | 'activity' | 'cases'>('officers')
  const [modal, setModal] = useState<Modal>(null)
  const [selected, setSelected] = useState<Account | null>(null)
  const [search, setSearch] = useState('')
  const [district, setDistrict] = useState('all')
  const [status, setStatus] = useState('all')
  const [page, setPage] = useState(1)
  const [busy, setBusy] = useState(false)
  const [formError, setFormError] = useState('')
  const [notice, setNotice] = useState('')
  const filtered = officers.filter(account => `${account.full_name} ${account.login_id} ${account.station} ${account.rank}`.toLowerCase().includes(search.toLowerCase()) && (district === 'all' || account.district === district) && (status === 'all' || account.enabled === (status === 'active')))
  const pageCount = Math.max(1, Math.ceil(filtered.length / 8))
  const visible = filtered.slice((Math.min(page, pageCount) - 1) * 8, Math.min(page, pageCount) * 8)
  function open(next: Modal, account: Account | null = null) { setFormError(''); setSelected(account); setModal(next) }
  async function signOut() { await queryClient.cancelQueries(); queryClient.clear(); await logout(); await router.invalidate(); await router.navigate({ to: '/staff-login', replace: true }) }
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setFormError('')
    const values = Object.fromEntries(new FormData(event.currentTarget))
    try {
      if (modal === 'login') {
        const result = await login({ data: { login_id: String(values['login_id']), password: String(values['password']) } })
        if (!result.ok) { setFormError(result.error); return }
        setNotice('Signed in securely.'); await refetch()
      } else if (modal === 'create') {
        if (values['password'] !== values['confirm_password']) { setFormError('Passwords do not match.'); return }
        const parsed = officerSchema.safeParse(values)
        if (!parsed.success) { setFormError(parsed.error.issues[0]?.message ?? 'Check the officer details.'); return }
        const result = await provision({ data: parsed.data })
        if (!result.ok) { setFormError(result.error); return }
        setNotice('Officer account created. Credentials must be shared through a trusted channel.'); await refetch()
      } else if (modal === 'password' && selected) {
        if (values['password'] !== values['confirm_password']) { setFormError('Passwords do not match.'); return }
        const parsed = passwordSchema.safeParse(values['password'])
        if (!parsed.success) { setFormError(parsed.error.issues[0]?.message ?? 'Check the password.'); return }
        const result = await changePassword({ data: { target_id: selected.id, password: parsed.data, reason: String(values['reason']) } })
        if (!result.ok) { setFormError(result.error); return }
        setNotice('Password changed. Previous sessions have been revoked.'); await refetch()
      } else if (modal === 'status' && selected) {
        const result = await changeStatus({ data: { target_id: selected.id, enabled: !selected.enabled, reason: String(values['reason']) } })
        if (!result.ok) { setFormError(result.error); return }
        setNotice(selected.enabled ? 'Officer access removed. Sign-in is blocked and existing sessions are revoked.' : 'Account reactivated. The officer can sign in again.'); await refetch()
      }
      setModal(null)
    } catch { setFormError('This action could not be completed. Check your access and try again.') }
    finally { setBusy(false) }
  }
  function exportOfficers() {
    const escape = (value: string) => `"${value.replaceAll('"', '""')}"`
    const csv = [['Officer ID', 'Full name', 'Rank', 'District', 'Station', 'Status'], ...filtered.map(account => [account.login_id, account.full_name, account.rank, account.district, account.station, account.enabled ? 'Active' : 'Disabled'])].map(row => row.map(escape).join(',')).join('\n')
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); const anchor = document.createElement('a'); anchor.href = url; anchor.download = 'securex-officers.csv'; anchor.click(); URL.revokeObjectURL(url)
  }
  return <div className="securex-shell admin-shell">
    <aside className="securex-sidebar"><Logo/><div className="nav-label">ADMINISTRATION</div><nav className="side-nav" aria-label="Administration">
      <Button variant="ghost" className={`nav-item ${tab === 'officers' ? 'active' : ''}`} onClick={() => setTab('officers')}><Users/>Officer management<span className="nav-count">{admin ? officers.length : '—'}</span></Button>
      <Button variant="ghost" className={`nav-item ${tab === 'cases' ? 'active' : ''}`} onClick={() => setTab('cases')}><Eye/>Watch Cases</Button>
      <Button variant="ghost" className={`nav-item ${tab === 'security' ? 'active' : ''}`} onClick={() => setTab('security')}><ShieldCheck/>Access & security</Button>
      <Button variant="ghost" className={`nav-item ${tab === 'activity' ? 'active' : ''}`} onClick={() => setTab('activity')}><Activity/>Activity log</Button>
      <Button asChild variant="ghost" className="nav-item"><Link to="/admin-locations"><Building2/>Service locations</Link></Button>
    </nav><div className="side-bottom"><div className="prototype-note"><strong><Shield size={14}/>Prototype environment</strong>Independent security software.<br/>Not an official police system.</div><div className="side-account"><span className="avatar">{me ? initials(me.full_name) : <LockKeyhole size={17}/>}</span><div><strong>{me ? (admin ? 'Administrator' : me.full_name) : 'Restricted access'}</strong><small>{me ? (admin ? 'Secure administration' : me.rank) : 'Staff sign-in required'}</small></div></div></div></aside>
    <main className="securex-main"><header className="topbar"><div className="breadcrumbs">Administration<ChevronRight size={12}/><strong>{tab === 'cases' ? 'Watch Cases' : tab === 'officers' ? 'Officer management' : tab === 'security' ? 'Access & security' : 'Activity log'}</strong></div><div className="topbar-actions"><div className="environment"><span/>Secure environment</div><Button variant="ghost" size="icon" aria-label="Account assistance" title="Account assistance" onClick={() => open('help')}><CircleHelp/></Button>{me ? <Button variant="ghost" onClick={signOut}><LogOut/><span className="button-label">Sign out</span></Button> : <Button variant="outline" onClick={() => open('login')}><LogIn/><span className="button-label">Sign in</span></Button>}</div></header>
      <div className="workspace"><div className="page-heading"><div><div className="eyebrow">{tab === 'cases' ? 'CITIZEN REGISTRATIONS' : 'PERSONNEL & ACCESS CONTROL'}</div><h1>{tab === 'cases' ? 'Watch Cases' : tab === 'officers' ? 'Officer management' : tab === 'security' ? 'Access & security' : 'Activity log'}</h1><p>{tab === 'cases' ? 'Household registrations and saved Police Watch timings.' : tab === 'officers' ? 'Manage officer profiles, credentials and station assignments.' : tab === 'security' ? 'Administrator-controlled credentials and secure staff access.' : 'A timestamped record of administrative account actions.'}</p></div>{tab === 'officers' && <Button className="heading-action" onClick={() => open(admin ? 'create' : 'login')}><Plus/>{admin ? 'Create officer' : 'Administrator sign in'}</Button>}</div>
      {notice && <div className="permission-banner" role="status"><CheckCircle2 size={19}/><strong>{notice}</strong></div>}
      {error && <div className="permission-banner" role="alert"><Activity size={19}/><strong>Staff records could not be loaded.</strong><Button variant="outline" size="sm" onClick={() => refetch()}><RefreshCw/>Retry</Button></div>}
      {tab !== 'cases' && <><div className="metrics">
        <Metric label="Registered officers" icon={<Users size={17}/>} value={admin ? officers.length : '—'} foot="Officer profiles on record"/>
        <Metric label="Active officers" icon={<UserCheck size={17}/>} value={admin ? officers.filter(a => a.enabled).length : '—'} foot="Enabled staff accounts" success/>
        <Metric label="Available capacity" icon={<Building2 size={17}/>} value={admin ? 50 - officers.filter(a => a.enabled).length : '—'} suffix=" / 50" foot="Maximum 50 active officers"/>
        <Metric label="Administrators" icon={<ShieldCheck size={17}/>} value={admin ? admins.filter(a => a.enabled).length : '—'} suffix=" / 5" foot="Authorized account managers"/>
      </div>
      <div className="permission-banner"><LockKeyhole size={21}/><div><strong>Administrator-only account controls</strong><p>Only administrators can create officer accounts and change passwords. Every action is recorded.</p></div><span className="badge"><ShieldCheck size={12}/>Protected access</span></div>
      </>}
      {tab === 'cases' ? <AdminWatchCases/> : tab === 'officers' ? <section className="directory"><div className="directory-heading"><div><h2>Officer directory <span className="badge neutral">{admin ? officers.length : 'Restricted'}</span></h2><p>Registered personnel and assigned stations</p></div><Button variant="ghost" size="icon" aria-label="Export officer directory" title="Export officer directory" disabled={!admin || !officers.length} onClick={exportOfficers}><Download/></Button></div><div className="directory-toolbar"><div className="search-field"><Search size={14}/><input className="field-input" aria-label="Search officers" placeholder="Search by name, officer ID or station..." value={search} onChange={e => { setSearch(e.target.value); setPage(1) }}/></div><div className="filters"><select className="field-input" aria-label="Filter district" value={district} onChange={e => { setDistrict(e.target.value); setPage(1) }}><option value="all">All districts</option>{[...new Set(officers.map(a => a.district))].map(d => <option key={d}>{d}</option>)}</select><select className="field-input" aria-label="Filter status" value={status} onChange={e => { setStatus(e.target.value); setPage(1) }}><option value="all">All statuses</option><option value="active">Active</option><option value="disabled">Disabled</option></select></div></div>
        <div className="table-wrap"><table><thead><tr><th>OFFICER</th><th>OFFICER ID</th><th>RANK</th><th>STATION & DISTRICT</th><th>STATUS</th><th>ACTIONS</th></tr></thead><tbody>{visible.map(account => <tr key={account.id}><td><div className="person-cell"><span className="avatar">{initials(account.full_name)}</span><div><strong>{account.full_name}</strong><small>{account.email || 'Officer account'}</small></div></div></td><td className="mono-id">{account.login_id}</td><td>{account.rank}</td><td><div className="person-cell"><div><strong>{account.station}</strong><small>{account.district}</small></div></div></td><td><span className={`badge ${account.enabled ? 'success' : 'neutral'}`}>{account.enabled ? <CheckCircle2 size={10}/> : <LockKeyhole size={10}/>} {account.enabled ? 'Active' : 'Disabled'}</span></td><td><div className="row-actions"><Button variant="ghost" size="icon" aria-label={`View ${account.full_name}`} title="View officer profile" onClick={() => open('profile', account)}><Eye/></Button><Button variant="ghost" size="icon" aria-label={`Change password for ${account.full_name}`} title="Change password" onClick={() => open('password', account)}><KeyRound/></Button><Button variant="ghost" size="icon" aria-label={`${account.enabled ? 'Remove access for' : 'Restore access for'} ${account.full_name}`} title={account.enabled ? 'Remove access' : 'Restore access'} onClick={() => open('status', account)}>{account.enabled ? <UserX/> : <UserCheck/>}</Button></div></td></tr>)}</tbody></table></div>
        {!visible.length && <div className="empty-directory"><div className="empty-icon">{me ? <Users size={23}/> : <LockKeyhole size={22}/>}</div><h3>{isPending ? 'Verifying secure access…' : !me ? 'Your officer directory is protected' : !admin ? 'Officer account access' : officers.length ? 'No matching officers' : 'Ready for your first officer'}</h3><p>{!me ? 'Sign in with your administrator-issued credentials to access staff records.' : !admin ? 'Your profile is available in Access & security. Contact an administrator for credential changes.' : officers.length ? 'Try a different name, district or status.' : 'No officer accounts have been created yet.'}</p>{!me ? <Button size="sm" onClick={() => open('login')}><LogIn/>Sign in securely</Button> : admin && !officers.length ? <Button size="sm" onClick={() => open('create')}><Plus/>Create first officer</Button> : null}</div>}
        <div className="directory-footer"><span>{admin ? `${filtered.length ? (Math.min(page,pageCount) - 1)*8+1 : 0}–${Math.min(Math.min(page,pageCount)*8,filtered.length)} of ${filtered.length} officers` : 'Authorized personnel only'}</span><div className="pagination"><Button variant="outline" size="icon" aria-label="Previous page" disabled={page <= 1} onClick={() => setPage(p => p-1)}><ChevronLeft/></Button><span>{Math.min(page,pageCount)} / {pageCount}</span><Button variant="outline" size="icon" aria-label="Next page" disabled={page >= pageCount} onClick={() => setPage(p => p+1)}><ChevronRight/></Button></div></div></section> : tab === 'security' ? <section className="directory"><div className="directory-heading"><div><h2>Account security</h2><p>Credential changes revoke previous sessions</p></div></div><div className="empty-directory">{me ? <><span className="avatar">{initials(me.full_name)}</span><h3 className="mt-4">{me.full_name}</h3><p>{me.rank} · {me.login_id}<br/>Last password update: {dateLabel(me.password_changed_at)}</p>{admin ? <Button onClick={() => open('password', me)}><KeyRound/>Change administrator password</Button> : <span className="badge"><LockKeyhole size={12}/>Password managed by your administrator</span>}</> : <><div className="empty-icon"><ShieldCheck size={22}/></div><h3>Sign in to view your account</h3><p>Account details are visible only after secure sign-in.</p><Button onClick={() => open('login')}><LogIn/>Sign in securely</Button></>}</div></section> : <section className="directory"><div className="directory-heading"><div><h2>Account action history</h2><p>Server-recorded actions · latest 100 entries</p></div></div><div className="p-6">{audit.length ? audit.map(item => <Audit key={item.id} item={item} accounts={accounts}/>) : <div className="activity-empty">{admin ? 'No account actions recorded yet.' : 'Sign in as an administrator to view action history.'}</div>}</div></section>}
      <div className="workspace-bottom"><section><div className="section-head"><h2>Recent activity</h2><Button variant="link" size="sm" onClick={() => setTab('activity')}>View all<ArrowUpRight/></Button></div>{audit.slice(0,3).map(item => <Audit key={item.id} item={item} accounts={accounts}/>)}{!audit.length && <div className="activity-empty">{admin ? 'Account actions will appear here once recorded.' : 'Activity is visible to authorized administrators.'}</div>}</section><section><div className="section-head"><h2>Security safeguards</h2><span className="badge success"><ShieldCheck size={11}/>Enforced</span></div><div className="security-line"><CheckCircle2 size={16}/><div>Administrator-controlled credentials<small>No officer self-service password changes</small></div></div><div className="security-line"><CheckCircle2 size={16}/><div>Secure password storage<small>Hashed passwords are never displayed</small></div></div><div className="security-line"><CheckCircle2 size={16}/><div>Accountable access<small>Timestamped actions and session revocation</small></div></div></section></div><footer className="page-foot"><span>© 2026 SECUREX · Personnel administration</span><span><LockKeyhole className="inline mr-1" size={10}/>Private records. Controlled access.</span></footer>
      </div>
    </main>
    <Dialog open={modal !== null} onOpenChange={value => { if (!value && !busy) setModal(null) }}><DialogContent className="secure-dialog"><DialogHeader><DialogTitle>{modal === 'login' ? 'Secure staff sign-in' : modal === 'create' ? 'Create officer profile' : modal === 'password' ? 'Change account password' : modal === 'profile' ? 'Officer profile' : modal === 'status' ? (selected?.enabled ? 'Remove officer access' : 'Restore officer access') : 'Account assistance'}</DialogTitle><DialogDescription>{modal === 'login' ? 'Use the ID and password issued by your administrator.' : modal === 'create' ? 'Issue a unique officer ID and initial password.' : modal === 'password' ? `${selected?.full_name ?? ''} · All previous sessions will be revoked.` : modal === 'profile' ? selected?.login_id : modal === 'status' ? `${selected?.full_name ?? ''} · ${selected?.enabled ? 'Sign-in will be blocked and current sessions revoked.' : 'Access will be restored within the active officer limit.'}` : 'SECUREX staff access is managed by administrators.'}</DialogDescription></DialogHeader>
      {(modal === 'login' || modal === 'create' || modal === 'password') && <form className="dialog-form" onSubmit={submit}>
        {modal === 'login' ? <><Field label="Staff ID" name="login_id" autoComplete="username"/><Field label="Password" name="password" type="password" autoComplete="current-password"/></> : <>
          {modal === 'create' && <><div className="form-grid"><Field label="Full name" name="full_name"/><Field label="Officer ID" name="login_id" placeholder="OFC-001"/></div><div className="form-grid"><Field label="Rank" name="rank" placeholder="Police Sub-Inspector"/><Field label="Email (optional)" name="email" type="email" required={false}/></div><div className="form-grid"><Field label="District" name="district"/><Field label="Police station" name="station"/></div></>}
          <div className="form-grid"><Field label={modal === 'create' ? 'Initial password' : 'New password'} name="password" type="password" autoComplete="new-password" minLength={12}/><Field label="Confirm password" name="confirm_password" type="password" autoComplete="new-password" minLength={12}/></div><p className="form-note">At least 12 characters with uppercase, lowercase, a number and a symbol. Share credentials only through a trusted channel.</p><Field label="Reason for this action" name="reason" placeholder={modal === 'create' ? 'New officer appointment' : 'Administrator-approved credential change'} minLength={5}/>
        </>}
        {formError && <p className="form-error" role="alert">{formError}</p>}<div className="modal-actions"><Button type="button" variant="outline" disabled={busy} onClick={() => setModal(null)}>Cancel</Button><Button type="submit" disabled={busy}>{busy ? <RefreshCw className="animate-spin"/> : modal === 'login' ? <LogIn/> : modal === 'create' ? <Plus/> : <KeyRound/>}{busy ? 'Please wait…' : modal === 'login' ? 'Sign in' : modal === 'create' ? 'Create officer' : 'Change password'}</Button></div>
      </form>}
      {modal === 'status' && selected && <form className="dialog-form" onSubmit={submit}><Field label="Reason for this action" name="reason" minLength={5} maxLength={500}/>{formError && <p className="form-error" role="alert">{formError}</p>}<div className="modal-actions"><Button type="button" variant="outline" disabled={busy} onClick={() => setModal(null)}>Cancel</Button><Button type="submit" variant={selected.enabled ? 'destructive' : 'default'} disabled={busy}>{busy ? <RefreshCw className="animate-spin"/> : selected.enabled ? <UserX/> : <UserCheck/>}{busy ? 'Please wait…' : selected.enabled ? 'Remove access' : 'Restore access'}</Button></div></form>}
      {modal === 'profile' && selected && <><dl className="profile-details">{[['Full name',selected.full_name],['Officer ID',selected.login_id],['Rank',selected.rank],['District',selected.district],['Station',selected.station],['Email',selected.email || 'Not provided'],['Created',dateLabel(selected.created_at)],['Password updated',dateLabel(selected.password_changed_at)]].map(([label,value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl><div className="modal-actions"><Button variant="outline" onClick={() => open('password', selected)}><KeyRound/>Change password</Button></div></>}
      {modal === 'help' && <div className="form-note">Contact your SECUREX administrator if you have forgotten your password or need an officer account. Officers cannot reset passwords themselves. This is a software prototype, not an emergency service.</div>}
    </DialogContent></Dialog>
  </div>
}
function Field({ label, ...props }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) { return <label className="form-field">{label}<input className="field-input" required maxLength={120} {...props}/></label> }
function Metric({ label, icon, value, suffix, foot, success }: { label: string; icon: React.ReactNode; value: string | number; suffix?: string; foot: string; success?: boolean }) { return <div className="metric"><div className="metric-top">{label}<span className="metric-icon">{icon}</span></div><div className="metric-value">{value}<small>{suffix}</small></div><div className={`metric-foot ${success ? 'success' : ''}`}>{success && <CheckCircle2 size={10}/>} {foot}</div></div> }
function Audit({ item, accounts }: { item: Workspace['audit'][number]; accounts: Account[] }) { const target = accounts.find(a => a.id === item.target_id); const actor = accounts.find(a => a.id === item.actor_id); return <div className="activity"><CheckCircle2 size={16}/><div><strong>{({ ACCOUNT_CREATED: 'Account created', PASSWORD_CHANGED: 'Password changed', ACCOUNT_DISABLED: 'Account disabled', ACCOUNT_REACTIVATED: 'Account reactivated' }[item.action] ?? 'Account action')} · {target?.full_name ?? 'Staff account'}</strong><p>{item.reason} · {actor?.full_name ?? 'Administrator'}</p><time dateTime={item.created_at}>{dateLabel(item.created_at)} · {new Date(item.created_at).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</time></div></div> }
