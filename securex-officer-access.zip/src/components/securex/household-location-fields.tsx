import { districtTowns, type RegistrationLocation } from '@/lib/registration-location'

type Props = {
  catalog: Record<string, string[]>
  locations: RegistrationLocation[]
  state: string
  district: string
  town: string
  onChange: (value: { state: string; district: string; town: string }) => void
}

export function HouseholdLocationFields({ catalog, locations, state, district, town, onChange }: Props) {
  const towns = districtTowns(district, catalog, locations)
  return <>
    <label className="form-field">State
      <select className="field-input" name="state" autoComplete="address-level1" required value={state} onChange={event => onChange({ state: event.target.value, district: '', town: '' })}>
        <option value="">Select state</option>
        <option value="Karnataka">Karnataka</option>
      </select>
    </label>
    <div className="form-grid">
      <label className="form-field">District
        <select className="field-input" name="district" required disabled={!state} value={district} onChange={event => onChange({ state, district: event.target.value, town: '' })}>
          <option value="">Select district</option>
          {state === 'Karnataka' && Object.keys(catalog).sort((a, b) => a.localeCompare(b)).map(name => <option key={name} value={name}>{name === 'Bengaluru South' ? 'Bengaluru South (Ramanagara)' : name}</option>)}
        </select>
      </label>
      <label className="form-field">Town
        <select className="field-input" name="town" autoComplete="address-level2" required disabled={!state || !district} value={town} onChange={event => onChange({ state, district, town: event.target.value })}>
          <option value="">Select town</option>
          {towns.map(name => <option key={name} value={name}>{name}</option>)}
        </select>
      </label>
    </div>
  </>
}