import { useEffect, type ReactNode } from 'react'
import { Link, useRouter } from '@tanstack/react-router'
import { useServerFn } from '@tanstack/react-start'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { LockKeyhole, RefreshCw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { getStaffIdentity } from '@/lib/staff.functions'
import { isAdministrator } from '@/lib/staff-policy'

// The server remains the security boundary; this removes stale private screens.
export function StaffAccessWatch({ administrator = false, children }: { administrator?: boolean; children: ReactNode }) {
  const identity = useServerFn(getStaffIdentity)
  const router = useRouter()
  const queryClient = useQueryClient()
  const { data, isPending, isError, refetch } = useQuery({
    queryKey: ['staff-live-access', administrator], queryFn: () => identity(),
    staleTime: 0, gcTime: 0, retry: false, refetchInterval: 10_000,
    refetchIntervalInBackground: true, refetchOnWindowFocus: 'always',
  })
  const permitted = data && (administrator ? isAdministrator(data.roles) : data.roles.includes('POLICE_OFFICER') && !isAdministrator(data.roles))
  useEffect(() => {
    if (isPending || isError || permitted) return
    const keys = ['staff-workspace', 'officer-workspace']
    for (const key of keys) {
      void queryClient.cancelQueries({ queryKey: [key] })
      queryClient.removeQueries({ queryKey: [key] })
    }
    void router.navigate({ to: administrator ? '/staff-login' : '/officer-login', replace: true })
  }, [isPending, isError, permitted, administrator, router, queryClient])
  if (isPending || isError || !permitted) return <main className="public-form-page login-page" aria-live="polite">
    <div className="form-intro"><span className="intro-icon"><LockKeyhole/></span><h1>{isPending ? 'Verifying access…' : isError ? 'Access check unavailable' : 'Officer access ended'}</h1><p>{isError ? 'Private records are hidden until your access can be verified.' : isPending ? 'SECUREX secure workspace' : 'Contact your administrator for access.'}</p></div>
    {isError && <Button variant="outline" onClick={() => refetch()}><RefreshCw/>Retry access check</Button>}
    {!isPending && !isError && <Button asChild><Link to={administrator ? '/staff-login' : '/officer-login'}>Return to login</Link></Button>}
  </main>
  return children
}